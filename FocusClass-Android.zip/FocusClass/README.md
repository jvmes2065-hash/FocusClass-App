# FocusClass (Android app for students)

Blocks every app except an **allowlist** during class hours. Settings come from the teacher's FocusClass website.

## Run it
1. Open this folder in **Android Studio** (it creates the Gradle wrapper automatically) and run on an Android 8.0+ phone.
2. Grant **Usage Access** and **Display over other apps**.
3. Log in or sign up, then tap **Join class** and enter the teacher's 6-letter class code.

The app syncs every 20 seconds. Schedule, on/off, pauses and allowed apps all follow the teacher.
Phone, SMS and the home screen are always allowed. Default PIN (to leave a class): `1234`.

`Config.kt` already contains the FocusClass Firebase project values. Students log in or sign up inside the app (Email/Password must be enabled in Firebase).

Limits: on personal phones a determined student can bypass this (safe mode, force stop). Use with student/parent consent.
