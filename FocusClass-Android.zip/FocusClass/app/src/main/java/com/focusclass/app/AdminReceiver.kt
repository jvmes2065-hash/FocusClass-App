package com.focusclass.app

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/** While this is active, FocusClass can't be uninstalled until the admin is switched off (and the teacher is told). */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Your teacher will be told if uninstall protection is turned off."

    override fun onDisabled(context: Context, intent: Intent) {
        val ctx = context.applicationContext
        Thread { Sync.record(ctx, "tamper", "Uninstall protection was turned off") }.start()
    }
}
