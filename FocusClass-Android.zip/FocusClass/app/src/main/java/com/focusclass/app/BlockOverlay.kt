package com.focusclass.app

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout

/**
 * Backup block screen drawn as a window over everything. Used when the phone (for example Xiaomi / MIUI) does not
 * let FocusClass open its block screen from the background. Needs only "Display over other apps".
 */
class BlockOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: View? = null
    val showing: Boolean get() = view != null

    fun show(message: String, onHome: () -> Unit, onAsk: () -> Unit) {
        if (view != null) return
        Ui.applyTheme((ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES)
        L.fil = Store(ctx).lang == "fil"
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = Ui.gradient(Ui.DARK, 0xFF0F172A.toInt())
            val p = Ui.dp(ctx, 32); setPadding(p, p, p, p)
        }
        root.add(Ui.label(ctx, "\uD83D\uDD12", 64f, Ui.WHITE).apply { gravity = Gravity.CENTER })
        root.add(Ui.label(ctx, "Blocked during class", 26f, Ui.WHITE, true).apply { gravity = Gravity.CENTER }, 12)
        root.add(Ui.label(ctx, message, 16f, Ui.SOFT).apply { gravity = Gravity.CENTER }, 8, 32)
        root.add(Ui.button(ctx, "Go to home screen") { onHome() }, 0, 12)
        val ask = Ui.button(ctx, "Ask my teacher for a pause", false) { onAsk() }
        ask.setOnClickListener { onAsk(); ask.text = "Request sent"; ask.isEnabled = false }
        root.add(ask, 0, 12)
        root.add(Ui.button(ctx, "Emergency call", false, Ui.BAD) {
            try { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
        })
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.OPAQUE)
        try { wm.addView(root, lp); view = root } catch (e: Exception) { }
    }

    fun hide() {
        view?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        view = null
    }
}
