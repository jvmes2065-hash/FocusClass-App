package com.focusclass.app

import android.content.Context

/** Remembers the last crash so the student can send it with "Send diagnostic info". */
object CrashLog {
    private var installed = false
    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val app = ctx.applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { Store(app).lastCrash = (e.toString() + " | " + e.stackTrace.take(5).joinToString(" | ")).take(900) } catch (x: Exception) { }
            old?.uncaughtException(t, e)
        }
    }
}
