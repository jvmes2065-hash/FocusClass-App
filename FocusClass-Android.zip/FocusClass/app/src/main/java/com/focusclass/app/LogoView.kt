package com.focusclass.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** The FocusClass logo (white tile, blue target rings) drawn in code. */
class LogoView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val s = width.toFloat(); val u = s / 100f; val m = s / 2
        p.style = Paint.Style.FILL; p.color = Color.WHITE
        cv.drawRoundRect(0f, 0f, s, s, 22 * u, 22 * u, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5 * u
        p.color = Ui.PRIMARY; cv.drawCircle(m, m, 31 * u, p)
        p.color = Color.parseColor("#93C5FD"); cv.drawCircle(m, m, 19 * u, p)
        p.style = Paint.Style.FILL; p.color = Ui.PRIMARY; cv.drawCircle(m, m, 7 * u, p)
    }
}
