package com.focusclass.app

/** Tiny translator: turns known English texts into Filipino when the student picks Filipino. */
object L {
    var fil = false

    private val FIL = mapOf(
        "Welcome" to "Maligayang pagdating",
        "Log in or create a student account to continue." to "Mag-log in o gumawa ng student account para magpatuloy.",
        "Log in" to "Mag-log in", "Create account" to "Gumawa ng account", "Forgot password?" to "Nakalimutan ang password?",
        "Home" to "Home", "My profile" to "Aking profile", "STATUS" to "KATAYUAN",
        "Allow usage access" to "Payagan ang usage access",
        "Lets FocusClass see which app is open so it can block the wrong ones." to "Para makita ng FocusClass kung aling app ang bukas at ma-block ang hindi pinapayagan.",
        "Open settings" to "Buksan ang settings",
        "Allow display over other apps" to "Payagan ang display over other apps",
        "Needed to show the \"Blocked during class\" screen." to "Kailangan para maipakita ang \"Blocked during class\" screen.",
        "Uninstall protection" to "Proteksyon laban sa pag-uninstall",
        "Stops FocusClass from being uninstalled during class. Your teacher is told if it is turned off." to "Pinipigilan ang pag-uninstall ng FocusClass habang may klase. Sasabihan ang guro mo kapag pinatay ito.",
        "Turn on" to "I-on", "Allow" to "Payagan",
        "Keep running in background" to "Manatiling tumatakbo sa background",
        "Stops the phone from putting FocusClass to sleep." to "Pinipigilan ang phone na patulugin ang FocusClass.",
        "Join your class" to "Sumali sa klase mo", "Enter the class code from your teacher." to "Ilagay ang class code mula sa guro mo.",
        "Join class" to "Sumali sa klase", "Join another class" to "Sumali sa isa pang klase",
        "Leave class (PIN)" to "Umalis sa klase (PIN)", "Allowed during class" to "Pinapayagan habang may klase",
        "Recent activity" to "Kamakailang aktibidad", "Log out" to "Mag-log out",
        "Days present" to "Araw na present", "Blocked today" to "Na-block ngayon", "Blocked total" to "Kabuuang na-block", "Alerts" to "Mga alerto",
        "Checked in" to "Nag-check in", "Joined class" to "Sumali sa klase", "Left class" to "Umalis sa klase", "Blocked app" to "Na-block na app",
        "Not in a class" to "Walang klase",
        "Nothing yet. Your activity shows here once you join a class." to "Wala pa. Lalabas dito ang aktibidad mo kapag sumali ka sa klase.",
        "Start after restart is off" to "Naka-off ang auto-start pagkatapos mag-restart",
        "Open auto-start settings" to "Buksan ang auto-start settings",
        "Join a class" to "Sumali sa klase", "Type the 6-letter class code from your teacher." to "I-type ang 6-letter class code mula sa guro mo.",
        "Join" to "Sumali", "Cancel" to "Kanselahin", "Enter the PIN" to "Ilagay ang PIN",
        "Privacy and consent" to "Privacy at pahintulot", "I agree" to "Sumasang-ayon ako", "Privacy & data" to "Privacy at data",
        "Usability survey" to "Usability survey", "Take the survey" to "Sagutan ang survey",
        "Help our research: answer 10 short questions about FocusClass." to "Tulungan ang research namin: sagutin ang 10 maikling tanong tungkol sa FocusClass.",
        "Language" to "Wika",
        "Working" to "Gumagana", "Working offline" to "Gumagana (offline)", "Not running" to "Hindi tumatakbo",
        "No class now" to "Walang klase ngayon", "Not in class" to "Wala sa klase",
        "Blocked during class" to "Naka-block habang may klase", "Go to home screen" to "Pumunta sa home screen",
        "Ask my teacher for a pause" to "Humingi ng pause sa guro", "Ask your teacher" to "Magtanong sa guro", "Send" to "Ipadala",
        "Submit" to "Ipadala", "Setup help" to "Tulong sa setup", "Open Xiaomi permissions" to "Buksan ang Xiaomi permissions", "Send diagnostic info" to "Ipadala ang diagnostic info",
        "New version available" to "May bagong bersyon", "Download" to "I-download", "Thank you!" to "Salamat!"
    )
    private val PREFIX = listOf(
        "Finish setup (" to "Tapusin ang setup (", "Your classes (" to "Mga klase mo (", "Class ends in " to "Matatapos ang klase sa ", "Next class in " to "Susunod na klase sa "
    )

    fun t(s: String): String {
        if (!fil) return s
        FIL[s]?.let { return it }
        for ((k, v) in PREFIX) if (s.startsWith(k)) return v + s.substring(k.length)
        return s
    }
}
