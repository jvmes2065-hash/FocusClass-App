package com.focusclass.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Student login + reading the teacher's class settings from Firebase over REST (no extra libraries). */
object Sync {
    private fun post(url: String, body: String, form: Boolean): JSONObject? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("Content-Type", if (form) "application/x-www-form-urlencoded" else "application/json")
        c.outputStream.use { it.write(body.toByteArray()) }
        return if (c.responseCode == 200) JSONObject(c.inputStream.bufferedReader().readText()) else null
    }

    private fun friendly(m: String) = when {
        m.startsWith("EMAIL_EXISTS") -> "That email already has an account. Try logging in."
        m.startsWith("INVALID_LOGIN") || m.startsWith("INVALID_PASSWORD") || m.startsWith("EMAIL_NOT_FOUND") -> "Wrong email or password."
        m.startsWith("WEAK_PASSWORD") -> "Password must be at least 6 characters."
        m.startsWith("INVALID_EMAIL") -> "Please enter a valid email."
        m.startsWith("TOO_MANY") -> "Too many tries. Please wait a moment."
        m.startsWith("OPERATION_NOT_ALLOWED") -> "Email sign-in is turned off in Firebase."
        else -> m
    }

    /** Log in or sign up. Returns an error message, or null on success. */
    fun auth(ctx: Context, signUp: Boolean, email: String, pw: String): String? {
        return try {
            val ep = if (signUp) "signUp" else "signInWithPassword"
            val c = URL("https://identitytoolkit.googleapis.com/v1/accounts:$ep?key=${Config.API_KEY}").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 8000; c.readTimeout = 8000
            c.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().put("email", email).put("password", pw).put("returnSecureToken", true)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val ok = c.responseCode == 200
            val j = JSONObject((if (ok) c.inputStream else c.errorStream).bufferedReader().readText())
            if (!ok) return friendly(j.getJSONObject("error").getString("message"))
            val s = Store(ctx)
            s.idToken = j.getString("idToken"); s.refreshToken = j.getString("refreshToken"); s.email = email
            s.tokenExp = System.currentTimeMillis() + (j.optString("expiresIn", "3600").toLong() - 120) * 1000
            null
        } catch (e: Exception) { "No internet connection." }
    }

    private fun token(s: Store): String? {
        if (s.idToken.isNotEmpty() && System.currentTimeMillis() < s.tokenExp) return s.idToken
        if (s.refreshToken.isEmpty()) return null
        val r = post("https://securetoken.googleapis.com/v1/token?key=${Config.API_KEY}",
            "grant_type=refresh_token&refresh_token=${s.refreshToken}", true) ?: return null
        s.idToken = r.getString("id_token"); s.refreshToken = r.getString("refresh_token")
        s.tokenExp = System.currentTimeMillis() + (r.optString("expires_in", "3600").toLong() - 120) * 1000
        return s.idToken
    }

    private fun num(f: JSONObject, k: String): Long {
        val o = f.getJSONObject(k)
        return if (o.has("integerValue")) o.getString("integerValue").toLong() else o.getDouble("doubleValue").toLong()
    }

    fun syncNow(ctx: Context) {
        val s = Store(ctx); val code = s.code
        if (code.isEmpty()) return
        try {
            val t = token(s)
            if (t == null) { s.status = "Sign-in problem. Check internet or log in again."; return }
            val url = "https://firestore.googleapis.com/v1/projects/${Config.PROJECT_ID}/databases/(default)/documents/classes/$code"
            val c = URL(url).openConnection() as HttpURLConnection
            c.setRequestProperty("Authorization", "Bearer $t"); c.connectTimeout = 8000; c.readTimeout = 8000
            when (c.responseCode) {
                200 -> {
                    val f = JSONObject(c.inputStream.bufferedReader().readText()).getJSONObject("fields")
                    s.enabled = f.getJSONObject("enabled").getBoolean("booleanValue")
                    s.startMin = num(f, "startMin").toInt(); s.endMin = num(f, "endMin").toInt()
                    s.pauseUntil = num(f, "pauseUntil")
                    val arr = f.getJSONObject("allowed").getJSONObject("arrayValue").optJSONArray("values")
                    val set = HashSet<String>()
                    if (arr != null) for (i in 0 until arr.length())
                        set += arr.getJSONObject(i).getJSONObject("mapValue").getJSONObject("fields").getJSONObject("pkg").getString("stringValue")
                    s.allowed = set
                    s.status = "Synced at " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                }
                404 -> s.status = "Class code not found"
                401 -> { s.idToken = ""; s.status = "Signing in again..." }
                else -> s.status = "Server error ${c.responseCode}"
            }
        } catch (e: Exception) { s.status = "No internet - using last settings" }
    }
}
