package com.focusclass.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Student login + reading each joined class's settings from Firebase over REST (no extra libraries). */
object Sync {
    private fun post(url: String, body: String, form: Boolean): JSONObject? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("Content-Type", if (form) "application/x-www-form-urlencoded" else "application/json")
        c.outputStream.use { it.write(body.toByteArray()) }
        return if (c.responseCode == 200) JSONObject(c.inputStream.bufferedReader().readText()) else null
    }

    private fun friendly(m: String) = when {
        m.startsWith("EMAIL_EXISTS") -> "That email already has an account. Try logging in."
        m.startsWith("INVALID_LOGIN") || m.startsWith("INVALID_PASSWORD") || m.startsWith("EMAIL_NOT_FOUND") -> "Wrong email or password."
        m.startsWith("WEAK_PASSWORD") -> "Password must be at least 6 characters."
        m.startsWith("INVALID_EMAIL") -> "Please enter a valid email."
        m.startsWith("TOO_MANY") -> "Too many tries. Please wait a moment."
        m.startsWith("OPERATION_NOT_ALLOWED") -> "Email sign-in is turned off in Firebase."
        else -> m
    }

    /** Log in or sign up. Returns an error message, or null on success. */
    fun auth(ctx: Context, signUp: Boolean, email: String, pw: String): String? {
        return try {
            val ep = if (signUp) "signUp" else "signInWithPassword"
            val c = URL("https://identitytoolkit.googleapis.com/v1/accounts:$ep?key=${Config.API_KEY}").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 8000; c.readTimeout = 8000
            c.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().put("email", email).put("password", pw).put("returnSecureToken", true)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val ok = c.responseCode == 200
            val j = JSONObject((if (ok) c.inputStream else c.errorStream).bufferedReader().readText())
            if (!ok) return friendly(j.getJSONObject("error").getString("message"))
            val s = Store(ctx)
            s.idToken = j.getString("idToken"); s.refreshToken = j.getString("refreshToken"); s.email = email; s.uid = j.getString("localId")
            s.tokenExp = System.currentTimeMillis() + (j.optString("expiresIn", "3600").toLong() - 120) * 1000
            null
        } catch (e: Exception) { "No internet connection." }
    }

    private fun token(s: Store): String? {
        if (s.idToken.isNotEmpty() && System.currentTimeMillis() < s.tokenExp) return s.idToken
        if (s.refreshToken.isEmpty()) return null
        val r = post("https://securetoken.googleapis.com/v1/token?key=${Config.API_KEY}",
            "grant_type=refresh_token&refresh_token=${s.refreshToken}", true) ?: return null
        s.idToken = r.getString("id_token"); s.refreshToken = r.getString("refresh_token")
        s.tokenExp = System.currentTimeMillis() + (r.optString("expires_in", "3600").toLong() - 120) * 1000
        return s.idToken
    }

    private fun num(f: JSONObject, k: String): Long {
        val o = f.getJSONObject(k)
        return if (o.has("integerValue")) o.getString("integerValue").toLong() else o.getDouble("doubleValue").toLong()
    }

    /** Refreshes every joined class. */
    fun syncNow(ctx: Context) {
        val s = Store(ctx)
        for (code in s.codes()) syncOne(ctx, s, code)
    }

    private fun syncOne(ctx: Context, s: Store, code: String) {
        val cs = s.cls(code)
        try {
            val t = token(s)
            if (t == null) { cs.status = "Sign-in problem. Check internet or log in again."; return }
            val url = "https://firestore.googleapis.com/v1/projects/${Config.PROJECT_ID}/databases/(default)/documents/classes/$code"
            val c = URL(url).openConnection() as HttpURLConnection
            c.setRequestProperty("Authorization", "Bearer $t"); c.connectTimeout = 8000; c.readTimeout = 8000
            when (c.responseCode) {
                200 -> {
                    val sd = c.getHeaderFieldDate("Date", 0L)
                    if (sd > 0) {
                        s.srvBase = sd; s.elBase = android.os.SystemClock.elapsedRealtime(); s.bootAtSync = s.currentBoot(); s.offset = sd - System.currentTimeMillis()
                        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(sd))
                        if (Math.abs(s.offset) > 120_000 && s.clockDay != day) {
                            s.clockDay = day; val mins = Math.abs(s.offset) / 60_000
                            Thread { record(ctx, "tamper", "Phone clock is about $mins min off from real time") }.start()
                        }
                    }
                    val f = JSONObject(c.inputStream.bufferedReader().readText()).getJSONObject("fields")
                    cs.name = f.optJSONObject("name")?.optString("stringValue") ?: ""
                    cs.enabled = f.getJSONObject("enabled").getBoolean("booleanValue")
                    cs.startMin = num(f, "startMin").toInt(); cs.endMin = num(f, "endMin").toInt()
                    cs.pauseUntil = num(f, "pauseUntil")
                    val arr = f.getJSONObject("allowed").getJSONObject("arrayValue").optJSONArray("values")
                    val set = HashSet<String>()
                    if (arr != null) for (i in 0 until arr.length())
                        set += arr.getJSONObject(i).getJSONObject("mapValue").getJSONObject("fields").getJSONObject("pkg").getString("stringValue")
                    cs.allowed = set
                    cs.pinHash = f.optJSONObject("pinHash")?.optString("stringValue") ?: ""
                    val pv = f.optJSONObject("periods")?.optJSONObject("arrayValue")?.optJSONArray("values")
                    val ps = org.json.JSONArray()
                    if (pv != null) for (i in 0 until pv.length()) {
                        val m = pv.getJSONObject(i).getJSONObject("mapValue").getJSONObject("fields")
                        val apps = org.json.JSONArray()
                        val av = m.optJSONObject("apps")?.optJSONObject("arrayValue")?.optJSONArray("values")
                        if (av != null) for (k in 0 until av.length()) apps.put(av.getJSONObject(k).getString("stringValue"))
                        ps.put(JSONObject().put("name", m.getJSONObject("name").getString("stringValue"))
                            .put("start", num(m, "start")).put("end", num(m, "end")).put("apps", apps))
                    }
                    cs.periodsJson = ps.toString()
                    val dv = f.optJSONObject("days")?.optJSONObject("arrayValue")?.optJSONArray("values")
                    cs.daysCsv = if (dv == null || dv.length() == 0) "23456" else (0 until dv.length()).joinToString("") {
                        val o = dv.getJSONObject(it)
                        if (o.has("integerValue")) o.getString("integerValue") else o.getDouble("doubleValue").toInt().toString()
                    }
                    cs.status = "Synced at " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                }
                404 -> cs.status = "Class code not found"
                401 -> { s.idToken = ""; cs.status = "Signing in again..." }
                else -> cs.status = "Server error ${c.responseCode}"
            }
        } catch (e: Exception) { cs.status = "No internet - using last settings" }
    }

    fun sha256(x: String) = java.security.MessageDigest.getInstance("SHA-256").digest(x.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun field(v: Any): JSONObject = when (v) {
        is Boolean -> JSONObject().put("booleanValue", v)
        is Int, is Long -> JSONObject().put("integerValue", v.toString())
        else -> JSONObject().put("stringValue", v.toString())
    }

    /** Writes a Firestore document over REST (patch = update/create one doc, otherwise add a new doc to a collection). */
    private fun write(ctx: Context, path: String, data: Map<String, Any>, patch: Boolean): Boolean {
        val t = token(Store(ctx)) ?: return false
        val base = "https://firestore.googleapis.com/v1/projects/${Config.PROJECT_ID}/databases/(default)/documents/$path"
        val url = if (patch) base + "?" + data.keys.joinToString("&") { "updateMask.fieldPaths=$it" } else base
        val fields = JSONObject(); for ((k, v) in data) fields.put(k, field(v))
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; if (patch) c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
        c.doOutput = true; c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("Authorization", "Bearer $t")
        c.outputStream.use { it.write(JSONObject().put("fields", fields).toString().toByteArray()) }
        return c.responseCode in 200..299
    }

    /** "I'm alive" signal so each teacher can see who is online. */
    fun heartbeat(ctx: Context) {
        val s = Store(ctx); if (s.uid.isEmpty()) return
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (s.blockedDay != today) { s.blockedDay = today; s.blocked = 0 }
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
        val admin = dpm.isAdminActive(android.content.ComponentName(ctx, AdminReceiver::class.java))
        for (code in s.codes()) {
            try {
                write(ctx, "classes/$code/students/${s.uid}",
                    mapOf("email" to s.email, "lastSeen" to s.now(), "blocked" to s.blocked, "admin" to admin), true)
            } catch (e: Exception) { }
        }
    }

    /** Adds a line to the class record of the given classes (all joined classes if none given). Offline: saved, sent later. */
    fun record(ctx: Context, type: String, text: String, codes: List<String>? = null) {
        val s = Store(ctx); if (s.uid.isEmpty()) return
        val targets = codes ?: s.codes()
        if (targets.isEmpty()) return
        s.addActivity(type, text)
        val at = s.now()
        for (c in targets) s.enqueue(type, text, at, c)
        flush(ctx)
    }

    private val flushLock = Any()

    /** Sends saved records to the teachers. Anything that fails stays saved and is tried again later. */
    fun flush(ctx: Context) {
        synchronized(flushLock) {
            val s = Store(ctx); if (s.uid.isEmpty()) return
            var sent = 0
            for (o in s.queueItems()) {
                val ok = try {
                    write(ctx, "classes/${o.getString("code")}/records",
                        mapOf("type" to o.getString("type"), "text" to o.getString("text"), "uid" to s.uid, "email" to s.email, "at" to o.getLong("at")), false)
                } catch (e: Exception) { false }
                if (!ok) break
                sent++
            }
            if (sent > 0) s.dropQueue(sent)
        }
    }
}
