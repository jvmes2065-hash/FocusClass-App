package com.focusclass.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Reads the teacher's class settings from Firestore over REST (anonymous sign-in, no extra libraries). */
object Sync {
    private fun post(url: String, body: String, form: Boolean): JSONObject? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("Content-Type", if (form) "application/x-www-form-urlencoded" else "application/json")
        c.outputStream.use { it.write(body.toByteArray()) }
        return if (c.responseCode == 200) JSONObject(c.inputStream.bufferedReader().readText()) else null
    }

    private fun token(s: Store): String? {
        if (s.idToken.isNotEmpty() && System.currentTimeMillis() < s.tokenExp) return s.idToken
        val key = Config.API_KEY
        var r: JSONObject? = null
        if (s.refreshToken.isNotEmpty())
            r = post("https://securetoken.googleapis.com/v1/token?key=$key", "grant_type=refresh_token&refresh_token=${s.refreshToken}", true)
        if (r == null) r = post("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$key", "{\"returnSecureToken\":true}", false)
        if (r == null) return null
        s.idToken = r.optString("idToken", r.optString("id_token"))
        s.refreshToken = r.optString("refreshToken", r.optString("refresh_token"))
        val exp = r.optString("expiresIn", r.optString("expires_in", "3600")).toLong()
        s.tokenExp = System.currentTimeMillis() + (exp - 120) * 1000
        return s.idToken
    }

    private fun num(f: JSONObject, k: String): Long {
        val o = f.getJSONObject(k)
        return if (o.has("integerValue")) o.getString("integerValue").toLong() else o.getDouble("doubleValue").toLong()
    }

    fun syncNow(ctx: Context) {
        val s = Store(ctx); val code = s.code
        if (code.isEmpty()) return
        try {
            val t = token(s)
            if (t == null) { s.status = "Sign-in failed (is Anonymous sign-in on?)"; return }
            val url = "https://firestore.googleapis.com/v1/projects/${Config.PROJECT_ID}/databases/(default)/documents/classes/$code"
            val c = URL(url).openConnection() as HttpURLConnection
            c.setRequestProperty("Authorization", "Bearer $t"); c.connectTimeout = 8000; c.readTimeout = 8000
            when (c.responseCode) {
                200 -> {
                    val f = JSONObject(c.inputStream.bufferedReader().readText()).getJSONObject("fields")
                    s.enabled = f.getJSONObject("enabled").getBoolean("booleanValue")
                    s.startMin = num(f, "startMin").toInt(); s.endMin = num(f, "endMin").toInt()
                    s.pauseUntil = num(f, "pauseUntil")
                    val arr = f.getJSONObject("allowed").getJSONObject("arrayValue").optJSONArray("values")
                    val set = HashSet<String>()
                    if (arr != null) for (i in 0 until arr.length())
                        set += arr.getJSONObject(i).getJSONObject("mapValue").getJSONObject("fields").getJSONObject("pkg").getString("stringValue")
                    s.allowed = set
                    s.status = "Synced at " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                }
                404 -> s.status = "Class code not found"
                401 -> { s.idToken = ""; s.status = "Signing in again..." }
                else -> s.status = "Server error ${c.responseCode}"
            }
        } catch (e: Exception) { s.status = "No internet - using last settings" }
    }
}
