package com.focusclass.app

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.*

/** System Usability Scale (SUS): 10 questions, answers 1 to 5. The score (0 to 100) is sent to the teacher. */
class SurveyActivity : Activity() {
    private val items = listOf(
        "I think that I would like to use FocusClass frequently.",
        "I found FocusClass unnecessarily complex.",
        "I thought FocusClass was easy to use.",
        "I think that I would need the support of a technical person to be able to use FocusClass.",
        "I found the various functions in FocusClass were well integrated.",
        "I thought there was too much inconsistency in FocusClass.",
        "I would imagine that most people would learn to use FocusClass very quickly.",
        "I found FocusClass very cumbersome to use.",
        "I felt very confident using FocusClass.",
        "I needed to learn a lot of things before I could get going with FocusClass."
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Ui.autoTheme(this); L.fil = Store(this).lang == "fil"
        window.statusBarColor = Ui.DARK
        val answers = IntArray(items.size)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val p = Ui.dp(this, 16); body.setPadding(p, p, p, p)
        val head = Ui.card(this)
        head.add(Ui.label(this, "Usability survey", 22f, Ui.TEXT, true))
        head.add(Ui.label(this, "Choose from 1 (strongly disagree) to 5 (strongly agree). There are no wrong answers.", 14f, Ui.MUTED), 4)
        body.add(head, 0, 12)
        for ((i, q) in items.withIndex()) {
            val c = Ui.card(this)
            c.add(Ui.label(this, "${i + 1}. $q", 15f, Ui.TEXT))
            val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
            for (n in 1..5) {
                val rb = RadioButton(this).apply { text = "$n"; id = View.generateViewId(); setTextColor(Ui.TEXT) }
                group.addView(rb, RadioGroup.LayoutParams(0, -2, 1f))
            }
            group.setOnCheckedChangeListener { g, checked -> answers[i] = g.findViewById<RadioButton>(checked).text.toString().toInt() }
            c.add(group, 8)
            body.add(c, 0, 10)
        }
        body.add(Ui.button(this, "Submit") {
            if (answers.any { it == 0 }) { Toast.makeText(this, "Please answer all 10 questions", Toast.LENGTH_SHORT).show(); return@button }
            val ctx = applicationContext
            Thread {
                val ok = Sync.submitSurvey(ctx, answers)
                runOnUiThread {
                    Toast.makeText(this, if (ok) L.t("Thank you!") else "Could not send. Check your internet and try again.", Toast.LENGTH_LONG).show()
                    if (ok) finish()
                }
            }.start()
        }, 8, 24)
        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.BG); addView(body) })
    }
}
