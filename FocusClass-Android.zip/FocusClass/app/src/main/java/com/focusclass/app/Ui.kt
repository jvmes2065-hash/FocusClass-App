package com.focusclass.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

/** Tiny styling helpers so the whole app looks consistent without XML layouts. */
object Ui {
    val PRIMARY = Color.parseColor("#2563EB"); val DARK = Color.parseColor("#1E3A8A")
    val BG = Color.parseColor("#F1F5F9"); val TEXT = Color.parseColor("#0F172A")
    val MUTED = Color.parseColor("#64748B"); val OK = Color.parseColor("#16A34A")
    val BAD = Color.parseColor("#DC2626"); val WHITE = Color.WHITE
    val LINE = Color.parseColor("#E2E8F0"); val SOFT = Color.parseColor("#BFDBFE")

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun shape(c: Context, fill: Int, radius: Int, stroke: Int = 0, sw: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(c, radius).toFloat(); if (sw > 0) setStroke(dp(c, sw), stroke)
    }

    fun gradient(a: Int, b: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b))

    fun label(c: Context, s: String, size: Float = 15f, color: Int = TEXT, bold: Boolean = false) = TextView(c).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; val p = dp(c, 18); setPadding(p, p, p, p)
        background = shape(c, WHITE, 16, LINE, 1)
    }

    fun button(c: Context, s: String, filled: Boolean = true, color: Int = PRIMARY, click: () -> Unit) = Button(c).apply {
        text = s; isAllCaps = false; textSize = 16f; stateListAnimator = null; minHeight = dp(c, 52)
        setTextColor(if (filled) WHITE else color); setTypeface(typeface, Typeface.BOLD)
        background = if (filled) shape(c, color, 12) else shape(c, WHITE, 12, color, 2)
        setOnClickListener { click() }
    }

    fun input(c: Context, hint: String, password: Boolean = false) = EditText(c).apply {
        this.hint = hint; setSingleLine(); setTextColor(TEXT); setHintTextColor(MUTED); textSize = 16f
        val p = dp(c, 14); setPadding(p, p, p, p); background = shape(c, BG, 12, LINE, 1)
        inputType = InputType.TYPE_CLASS_TEXT or
            if (password) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
    }

    fun badge(c: Context, s: String, color: Int) = TextView(c).apply {
        text = s; textSize = 16f; setTextColor(WHITE); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER
        background = shape(c, color, 20); minWidth = dp(c, 36); minHeight = dp(c, 36)
    }
}

/** Add a child with top/bottom margins (dp), full width. */
fun LinearLayout.add(v: View, top: Int = 0, bottom: Int = 0): View {
    val lp = LinearLayout.LayoutParams(-1, -2)
    lp.topMargin = Ui.dp(context, top); lp.bottomMargin = Ui.dp(context, bottom)
    addView(v, lp); return v
}
