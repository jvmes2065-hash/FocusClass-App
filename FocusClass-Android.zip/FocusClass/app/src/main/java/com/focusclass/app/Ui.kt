package com.focusclass.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.drawable.ColorDrawable
import android.view.WindowManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

/** Tiny styling helpers so the whole app looks consistent without XML layouts. */
object Ui {
    val PRIMARY = Color.parseColor("#2563EB"); val DARK = Color.parseColor("#1E3A8A")
    val BG = Color.parseColor("#F1F5F9"); val TEXT = Color.parseColor("#0F172A")
    val MUTED = Color.parseColor("#64748B"); val OK = Color.parseColor("#16A34A")
    val BAD = Color.parseColor("#DC2626"); val WHITE = Color.WHITE
    val LINE = Color.parseColor("#E2E8F0"); val SOFT = Color.parseColor("#BFDBFE")

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun shape(c: Context, fill: Int, radius: Int, stroke: Int = 0, sw: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(c, radius).toFloat(); if (sw > 0) setStroke(dp(c, sw), stroke)
    }

    fun gradient(a: Int, b: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b))

    fun label(c: Context, s: String, size: Float = 15f, color: Int = TEXT, bold: Boolean = false) = TextView(c).apply {
        text = s; textSize = size * 1.12f; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; val p = dp(c, 18); setPadding(p, p, p, p)
        background = shape(c, WHITE, 16, LINE, 1)
    }

    fun button(c: Context, s: String, filled: Boolean = true, color: Int = PRIMARY, click: () -> Unit) = Button(c).apply {
        text = s; isAllCaps = false; textSize = 17f; stateListAnimator = null; minHeight = dp(c, 56)
        setTextColor(if (filled) WHITE else color); setTypeface(typeface, Typeface.BOLD)
        background = if (filled) shape(c, color, 12) else shape(c, WHITE, 12, color, 2)
        setOnClickListener { click() }
    }

    fun input(c: Context, hint: String, password: Boolean = false) = EditText(c).apply {
        this.hint = hint; setSingleLine(); setTextColor(TEXT); setHintTextColor(MUTED); textSize = 18f
        val p = dp(c, 14); setPadding(p, p, p, p); background = shape(c, BG, 12, LINE, 1)
        inputType = InputType.TYPE_CLASS_TEXT or
            if (password) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
    }

    /** Big centered input for class codes (letters) or PINs (numbers). */
    fun codeInput(c: Context, hint: String, numeric: Boolean) = EditText(c).apply {
        this.hint = hint; setSingleLine(); setTextColor(TEXT); setHintTextColor(MUTED); textSize = 24f; gravity = Gravity.CENTER
        letterSpacing = 0.15f; val p = dp(c, 14); setPadding(p, p, p, p); background = shape(c, BG, 14, LINE, 1)
        inputType = if (numeric) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    }

    /** Modern rounded dialog with a title, a message, an optional input and Cancel / OK buttons. */
    fun dialog(a: Activity, title: String, msg: String, field: EditText?, ok: String, onOk: () -> Unit) {
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; val p = dp(a, 22); setPadding(p, p, p, p); background = shape(a, WHITE, 24)
        }
        box.add(label(a, title, 20f, TEXT, true))
        box.add(label(a, msg, 14f, MUTED), 6)
        if (field != null) box.add(field, 16)
        val d = AlertDialog.Builder(a).setView(box).create()
        val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button(a, "Cancel", false, MUTED) { d.dismiss() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(a, 8) })
        row.addView(button(a, ok, true) { d.dismiss(); onOk() }, LinearLayout.LayoutParams(0, -2, 1f))
        box.add(row, 20)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        d.show()
        field?.requestFocus()
    }

    fun badge(c: Context, s: String, color: Int) = TextView(c).apply {
        text = s; textSize = 16f; setTextColor(WHITE); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER
        background = shape(c, color, 20); minWidth = dp(c, 36); minHeight = dp(c, 36)
    }
}

/** Add a child with top/bottom margins (dp), full width. */
fun LinearLayout.add(v: View, top: Int = 0, bottom: Int = 0): View {
    val lp = LinearLayout.LayoutParams(-1, -2)
    lp.topMargin = Ui.dp(context, top); lp.bottomMargin = Ui.dp(context, bottom)
    addView(v, lp); return v
}
