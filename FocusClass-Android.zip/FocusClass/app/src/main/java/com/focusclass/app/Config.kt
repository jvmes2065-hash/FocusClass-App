package com.focusclass.app

/** Your Firebase project (same values as the website's firebase-config.js). */
object Config {
    const val API_KEY = "AIzaSyDq8EN8W37HWBxckTb3Ls9lVxXo5xsPS9w"
    const val PROJECT_ID = "focusclass-bca1b"
}
