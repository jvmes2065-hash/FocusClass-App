package com.focusclass.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** A tiny round mascot that runs in a loop while FocusClass is working, and sleeps when it is not. */
class RunnerView(c: Context) : View(c) {
    var working = false
        set(v) { field = v; invalidate() }
    private var phase = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val anim = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 650; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; if (working) invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val u = width / 44f
        val run = working
        val t = phase / (2 * Math.PI.toFloat())
        val s = if (run) sin(phase) else 0f
        val bob = if (run) abs(sin(phase)) * 2f else 0f
        val by = (if (run) 19f else 22f) - bob
        val ink = Color.parseColor("#1E3A8A")

        if (run) { // speed lines behind the runner
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.4f * u; p.color = Color.argb(150, 255, 255, 255)
            for (k in 0..2) {
                val x0 = (t * 6f + k * 2f) % 6f; val y = (15f + k * 6f) * u
                cv.drawLine(x0 * u, y, (x0 + 3f) * u, y, p)
            }
        }
        p.style = Paint.Style.STROKE; p.color = Color.WHITE
        val legLen = if (run) 9f else 5f
        p.strokeWidth = 4f * u
        for (side in 0..1) { // legs
            val x = if (side == 0) 18f else 26f
            val a = if (run) (if (side == 0) s else -s) * 0.75f else 0f
            cv.drawLine(x * u, (by + 9f) * u, (x + sin(a) * legLen) * u, (by + 9f + cos(a) * legLen) * u, p)
        }
        p.strokeWidth = 3f * u
        for (side in 0..1) { // arms
            val x = if (side == 0) 12.5f else 31.5f
            val a = if (run) (if (side == 0) -s else s) * 0.9f else (if (side == 0) -0.25f else 0.25f)
            cv.drawLine(x * u, (by + 1f) * u, (x + sin(a) * 7f) * u, (by + 1f + cos(a) * 7f) * u, p)
        }
        p.style = Paint.Style.FILL; p.color = Color.WHITE
        cv.drawCircle(22f * u, by * u, 11f * u, p) // body
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.6f * u
        cv.drawLine(22f * u, (by - 11f) * u, 22f * u, (by - 14f) * u, p) // tuft
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#FDE68A")
        cv.drawCircle(22f * u, (by - 14.5f) * u, 2f * u, p)
        p.color = Color.parseColor("#FBCFE8") // cheeks
        cv.drawCircle(16f * u, (by + 3.5f) * u, 2f * u, p); cv.drawCircle(28f * u, (by + 3.5f) * u, 2f * u, p)
        p.color = ink
        if (run) {
            cv.drawCircle(18.5f * u, (by - 1f) * u, 1.7f * u, p); cv.drawCircle(25.5f * u, (by - 1f) * u, 1.7f * u, p)
        } else {
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.3f * u
            cv.drawLine(16.8f * u, (by - 1f) * u, 20.2f * u, (by - 1f) * u, p)
            cv.drawLine(23.8f * u, (by - 1f) * u, 27.2f * u, (by - 1f) * u, p)
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.3f * u; p.color = ink
        cv.drawArc(19f * u, (by + 1.5f) * u, 25f * u, (by + 6f) * u, 20f, 140f, false, p) // smile
        if (!run) { // sleeping "z z"
            p.style = Paint.Style.FILL; p.color = Color.parseColor("#BFDBFE")
            p.textSize = 8f * u; cv.drawText("z", 32f * u, 9f * u, p)
            p.textSize = 5f * u; cv.drawText("z", 37f * u, 5f * u, p)
        }
    }
}
