package com.focusclass.app

import android.app.Activity
import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val PRIVACY = "FocusClass collects only what it needs: your email, the classes you join, your attendance and when your phone is online, the names of apps you tried to open during class, your phone model, and security alerts (like turning protection off). The teachers of your classes can see this. It is stored in Firebase, used for this study and class management, and not sold. Ask your teacher to remove you from a class if you want your class data removed."

class MainActivity : Activity() {
    private lateinit var store: Store
    private val handler = Handler(Looper.getMainLooper())
    private var statusView: TextView? = null
    private var tab = "home"
    private var runner: RunnerView? = null
    private var runnerLabel: TextView? = null
    private val ticker = object : Runnable {
        override fun run() { statusView?.text = statusText(); updateRunner(); handler.postDelayed(this, 3000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        Ui.autoTheme(this); L.fil = store.lang == "fil"
        window.statusBarColor = Ui.DARK
        if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
    }

    override fun onResume() {
        super.onResume()
        RestartJob.schedule(applicationContext)
        if (store.loggedIn && store.hasClass()) {
            // If class is on but FocusClass was not started by the phone after its last restart, remember it (shows a tip).
            val boot = System.currentTimeMillis() - SystemClock.elapsedRealtime()
            if (store.inWatchWindow() && store.lastAlive in 1L until boot) store.bootMissed = true
            val ctx = applicationContext
            Thread { // opening the app refreshes the teachers' settings, then starts protection only if class is on
                Sync.syncNow(ctx); Sync.flush(ctx)
                if (Store(ctx).inWatchWindow()) runOnUiThread {
                    try { startForegroundService(Intent(this, BlockerService::class.java)) } catch (e: Exception) { }
                }
            }.start()
        }
        render(); handler.postDelayed(ticker, 3000)
    }

    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    private fun render() { setContentView(if (store.loggedIn) dashboard() else loginView()) }

    /** The blue top bar. With showRunner, a little mascot runs in the top-right corner while the app is working. */
    private fun header(sub: String, big: Boolean, showRunner: Boolean = false): View {
        val text = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 24), Ui.dp(context, if (big) 56 else 32), Ui.dp(context, 24), Ui.dp(context, if (big) 40 else 24))
            add(Ui.label(context, "FocusClass", if (big) 36f else 28f, Ui.WHITE, true))
            add(Ui.label(context, sub, 14f, Ui.SOFT), 4)
        }
        return FrameLayout(this).apply {
            background = Ui.gradient(Ui.DARK, Ui.PRIMARY)
            addView(text, FrameLayout.LayoutParams(-1, -2))
            if (showRunner) {
                val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
                val r = RunnerView(context); val l = Ui.label(context, "", 10f, Ui.SOFT).apply { gravity = Gravity.CENTER }
                runner = r; runnerLabel = l
                box.addView(r, LinearLayout.LayoutParams(Ui.dp(context, 48), Ui.dp(context, 48)))
                box.addView(l, LinearLayout.LayoutParams(-2, -2))
                addView(box, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
                    topMargin = Ui.dp(context, 12); rightMargin = Ui.dp(context, 16) })
                updateRunner()
            }
        }
    }

    /** Running = the protection service is alive (works offline too). Sleeping = it is not running. */
    private fun updateRunner() {
        val r = runner ?: return
        val joined = store.hasClass()
        val working = joined && hasUsage() && Settings.canDrawOverlays(this) && System.currentTimeMillis() - store.lastTick < 15_000
        val standby = joined && !store.inWatchWindow()
        r.working = working && !standby
        runnerLabel?.text = if (!joined) "Not in class" else if (standby) "No class now" else if (!working) "Not running"
            else if (store.offline()) "Working offline" else "Working"
    }

    private fun page(head: View, body: LinearLayout): View = ScrollView(this).apply {
        setBackgroundColor(Ui.BG)
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(head, LinearLayout.LayoutParams(-1, -2))
            val p = Ui.dp(context, 16); body.setPadding(p, p, p, p)
            addView(body, LinearLayout.LayoutParams(-1, -2))
        })
    }

    /* ---------- Login / sign up ---------- */
    private fun loginView(): View {
        statusView = null; runner = null; runnerLabel = null
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val card = Ui.card(this)
        card.add(Ui.label(this, "Welcome", 22f, Ui.TEXT, true))
        card.add(Ui.label(this, "Log in or create a student account to continue.", 14f, Ui.MUTED), 4, 16)
        val email = Ui.input(this, "Email"); val pw = Ui.input(this, "Password (6+ characters)", true)
        card.add(email, 0, 10); card.add(pw)
        val msg = Ui.label(this, "", 14f, Ui.BAD); card.add(msg, 8, 8)
        lateinit var b1: Button; lateinit var b2: Button
        fun go(signUp: Boolean) {
            val e = email.text.toString().trim(); val p = pw.text.toString()
            if (e.isEmpty() || p.isEmpty()) { msg.text = "Enter your email and password."; return }
            msg.setTextColor(Ui.MUTED); msg.text = "Please wait..."; b1.isEnabled = false; b2.isEnabled = false
            Thread {
                val err = Sync.auth(applicationContext, signUp, e, p)
                runOnUiThread {
                    if (err == null) render() else { msg.setTextColor(Ui.BAD); msg.text = err; b1.isEnabled = true; b2.isEnabled = true }
                }
            }.start()
        }
        b1 = Ui.button(this, "Log in") { go(false) }
        b2 = Ui.button(this, "Create account", false) { Ui.dialog(this, "Privacy and consent", PRIVACY, null, "I agree") { go(true) } }
        card.add(b1, 0, 10); card.add(b2, 0, 10)
        card.add(Ui.button(this, "Forgot password?", false, Ui.MUTED) {
            val e = email.text.toString().trim()
            if (e.isEmpty()) { msg.setTextColor(Ui.BAD); msg.text = "Type your email first."; return@button }
            msg.setTextColor(Ui.MUTED); msg.text = "Please wait..."
            Thread {
                val err = Sync.resetPassword(applicationContext, e)
                runOnUiThread { msg.setTextColor(if (err == null) Ui.OK else Ui.BAD); msg.text = err ?: "Reset link sent. Check your email (and spam)." }
            }.start()
        })
        body.add(card)
        return page(header("Stay focused. Learn better.", true), body)
    }

    /* ---------- Main screen: Home / My profile ---------- */
    private fun dashboard(): View {
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.add(tabBar(), 0, 12)
        statusView = null
        if (tab == "profile") profile(body) else home(body)
        return page(header(store.email, false, true), body)
    }

    private fun tabBar(): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for ((id, name) in listOf("home" to "Home", "profile" to "My profile")) {
            addView(Ui.button(context, name, tab == id) { tab = id; render() },
                LinearLayout.LayoutParams(0, -2, 1f).apply { if (id == "home") rightMargin = Ui.dp(context, 8) })
        }
    }

    /** Home: status, only the setup steps that are NOT done yet, and the classes you joined. */
    private fun home(body: LinearLayout) {
        val u = hasUsage(); val o = Settings.canDrawOverlays(this); val ad = adminOn(); val bt = batteryOk()
        val classes = store.classes()
        val sc = Ui.card(this)
        sc.add(Ui.label(this, "STATUS", 12f, Ui.MUTED, true))
        statusView = Ui.label(this, statusText(), 16f); sc.add(statusView!!, 6)
        body.add(sc, 0, 12)

        if (classes.isNotEmpty() && store.bootMissed) body.add(step(-1, "Start after restart is off",
            "FocusClass did not start by itself after your phone restarted, so it was not blocking until you opened it. Allow auto-start for FocusClass in the app settings (battery or auto-launch), then restart once to test.", false).apply {
            add(Ui.button(context, "Open auto-start settings") { openAutoStart() }, 12) }, 0, 12)

        val left = listOf(u, o, ad, bt).count { !it }
        if (left > 0) body.add(Ui.label(this, "Finish setup ($left left)", 15f, Ui.TEXT, true), 4, 8)
        if (!u) body.add(step(1, "Allow usage access", "Lets FocusClass see which app is open so it can block the wrong ones.", false).apply {
            add(Ui.button(context, "Open settings") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, 12) }, 0, 12)
        if (!o) body.add(step(2, "Allow display over other apps", "Needed to show the \"Blocked during class\" screen.", false).apply {
            add(Ui.button(context, "Open settings") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }, 12) }, 0, 12)
        if (!ad) body.add(step(3, "Uninstall protection", "Stops FocusClass from being uninstalled during class. Your teacher is told if it is turned off.", false).apply {
            add(Ui.button(context, "Turn on") {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminCn)
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Stops FocusClass from being uninstalled during class. Your teacher is told if it is turned off.")) }, 12) }, 0, 12)
        if (!bt) body.add(step(4, "Keep running in background", "Stops the phone from putting FocusClass to sleep.", false).apply {
            add(Ui.button(context, "Allow") {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }, 12) }, 0, 12)

        if (classes.isEmpty()) {
            body.add(step(5, "Join your class", "Enter the class code from your teacher.", false).apply {
                add(Ui.button(context, "Join class") { join() }, 12) }, 0, 12)
        } else {
            body.add(Ui.label(this, "Your classes (${classes.size})", 15f, Ui.TEXT, true), 4, 8)
            for (cs in classes) body.add(classCard(cs), 0, 12)
            body.add(Ui.button(this, "Join another class", false) { join() }, 0, 12)
        }
    }

    private fun classCard(cs: ClassStore): View {
        val c = Ui.card(this)
        c.add(Ui.label(this, cs.label(), 20f, Ui.TEXT, true))
        c.add(Ui.label(this, "Code ${cs.code}", 13f, Ui.PRIMARY, true), 2)
        val cd = cs.countdown()
        if (cd.isNotEmpty()) c.add(Ui.label(this, cd, 15f, Ui.PRIMARY, true), 6)
        if (cs.isPaused()) c.add(Ui.label(this, "Paused by your teacher until ${cs.pausedClock()}", 14f, Ui.OK, true), 6)
        c.add(Ui.label(this, cs.scheduleText(), 14f, Ui.MUTED), 8)
        c.add(Ui.label(this, "Allowed during class", 14f, Ui.TEXT, true), 12, 4)
        c.add(Ui.label(this, allowedNames(cs), 14f, Ui.MUTED))
        c.add(Ui.button(this, "Leave class (PIN)", false, Ui.BAD) { needPin(cs) { leave(cs) } }, 16)
        return c
    }

    /** My profile: the student's own stats and activity log. */
    private fun profile(body: LinearLayout) {
        val c = Ui.card(this)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(Ui.badge(this, store.email.take(1).uppercase(), Ui.PRIMARY).apply { textSize = 22f; minWidth = Ui.dp(context, 56); minHeight = Ui.dp(context, 56) })
        val who = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        who.addView(Ui.label(this, store.email, 16f, Ui.TEXT, true))
        val n = store.codes().size
        who.addView(Ui.label(this, if (n == 0) "Not in a class" else "$n class${if (n > 1) "es" else ""}", 13f, Ui.MUTED))
        row.addView(who, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = Ui.dp(this@MainActivity, 14) })
        c.add(row)
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(store.daysPresent to "Days present", store.blocked to "Blocked today", store.blockedTotal to "Blocked total", store.alertsTotal to "Alerts").forEachIndexed { i, (num, l) ->
            stats.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                val p = Ui.dp(context, 8); setPadding(p, p * 5 / 4, p, p * 5 / 4); background = Ui.shape(context, Ui.BG, 12)
                addView(Ui.label(context, "$num", 20f, Ui.TEXT, true).apply { gravity = Gravity.CENTER })
                addView(Ui.label(context, l, 11f, Ui.MUTED).apply { gravity = Gravity.CENTER })
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = Ui.dp(this@MainActivity, 6) })
        }
        c.add(stats, 16)
        body.add(c, 0, 12)

        val act = Ui.card(this)
        act.add(Ui.label(this, "Recent activity", 17f, Ui.TEXT, true), 0, 6)
        val items = store.activity()
        if (items.isEmpty()) act.add(Ui.label(this, "Nothing yet. Your activity shows here once you join a class.", 14f, Ui.MUTED))
        val fmt = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
        val names = mapOf("checkin" to "Checked in", "joined" to "Joined class", "left" to "Left class", "blocked" to "Blocked app", "tamper" to "Security alert")
        for (a in items.take(30)) {
            act.addView(View(this).apply { setBackgroundColor(Ui.LINE) }, LinearLayout.LayoutParams(-1, Ui.dp(this, 1)).apply { topMargin = Ui.dp(this@MainActivity, 8) })
            act.add(Ui.label(this, names[a.second] ?: a.second, 15f, if (a.second == "tamper") Ui.BAD else Ui.TEXT, true), 8)
            act.add(Ui.label(this, a.third, 13f, Ui.MUTED))
            act.add(Ui.label(this, fmt.format(Date(a.first)), 12f, Ui.MUTED))
        }
        body.add(act, 0, 12)

        val more = Ui.card(this)
        more.add(Ui.label(this, "Usability survey", 17f, Ui.TEXT, true))
        more.add(Ui.label(this, "Help our research: answer 10 short questions about FocusClass.", 14f, Ui.MUTED), 4)
        more.add(Ui.button(this, "Take the survey") {
            if (store.hasClass()) startActivity(Intent(this, SurveyActivity::class.java)) else toast("Join a class first") }, 12)
        body.add(more, 0, 12)

        val lang = Ui.card(this)
        lang.add(Ui.label(this, "Language", 17f, Ui.TEXT, true))
        val lrow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        lrow.addView(Ui.button(this, "English", store.lang != "fil") { store.lang = "en"; L.fil = false; render() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = Ui.dp(this@MainActivity, 8) })
        lrow.addView(Ui.button(this, "Filipino", store.lang == "fil") { store.lang = "fil"; L.fil = true; render() }, LinearLayout.LayoutParams(0, -2, 1f))
        lang.add(lrow, 10)
        body.add(lang, 0, 12)

        val priv = Ui.card(this)
        priv.add(Ui.label(this, "Privacy & data", 17f, Ui.TEXT, true))
        priv.add(Ui.label(this, PRIVACY, 13f, Ui.MUTED), 4)
        body.add(priv, 0, 12)
        body.add(Ui.button(this, "Log out", false, Ui.MUTED) {
            if (store.hasClass()) toast("Leave your classes first (each needs the teacher's PIN)") else logout() }, 8)
    }

    private fun step(n: Int, title: String, desc: String, done: Boolean): LinearLayout {
        val c = Ui.card(this)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(Ui.badge(this, if (done) "\u2713" else if (n < 0) "!" else "$n", if (done) Ui.OK else if (n < 0) Ui.BAD else Ui.PRIMARY))
        row.addView(Ui.label(this, title, 17f, Ui.TEXT, true),
            LinearLayout.LayoutParams(-2, -2).apply { leftMargin = Ui.dp(this@MainActivity, 12) })
        c.add(row); c.add(Ui.label(this, desc, 14f, Ui.MUTED), 8)
        return c
    }

    private fun allowedNames(cs: ClassStore): String {
        val names = cs.allowed.mapNotNull {
            try { packageManager.getApplicationInfo(it, 0).loadLabel(packageManager).toString() } catch (e: Exception) { null }
        }.sorted()
        return "Phone, Messages and your home screen are always allowed." + if (names.isEmpty()) "" else "\n" + names.joinToString(", ")
    }

    private fun statusText(): String {
        val on = listOf(hasUsage(), Settings.canDrawOverlays(this), adminOn(), batteryOk()).count { it }
        val prot = if (on == 4) "Protection: all on" else "Protection: $on of 4 on"
        val classes = store.classes()
        if (classes.isEmpty()) return "Not in a class yet.\n$prot"
        val q = store.queueSize()
        return classes.joinToString("\n\n") {
            "${it.label()} (${it.code})\n${it.status}\nClass mode: ${if (it.enabled) "ON" else "OFF"}  |  ${it.whenText()}" + (if (it.countdown().isNotEmpty()) "\n" + it.countdown() else "")
        } + "\n\n" + (if (q > 0) "Waiting to send: $q update${if (q > 1) "s" else ""}\n" else "") + prot
    }

    private fun hasUsage(): Boolean {
        val m = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return m.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun adminOn() = (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(adminCn)
    private val adminCn get() = ComponentName(this, AdminReceiver::class.java)
    private fun batteryOk() = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    /** Join one more class (you can join several). */
    private fun join() {
        if (!hasUsage() || !Settings.canDrawOverlays(this) || !adminOn()) { toast("Finish steps 1 to 3 first"); return }
        val et = Ui.codeInput(this, "ABC123", false)
        Ui.dialog(this, "Join a class", "Type the 6-letter class code from your teacher.", et, "Join") {
            val code = et.text.toString().trim().uppercase()
            if (code.isEmpty()) return@dialog
            if (code in store.codes()) { toast("You already joined this class"); return@dialog }
            store.addCode(code); store.cls(code).status = "Connecting..."
            val ctx = applicationContext
            Thread {
                Sync.syncNow(ctx)
                val st = Store(ctx)
                if (st.cls(code).status == "Class code not found") {
                    st.removeCode(code)
                    runOnUiThread { toast("Class code not found. Check the code and try again."); render() }
                    return@Thread
                }
                Sync.record(ctx, "joined", "Joined ${st.cls(code).label()}", listOf(code)); Sync.heartbeat(ctx)
                runOnUiThread {
                    if (Store(ctx).inWatchWindow()) startForegroundService(Intent(this, BlockerService::class.java))
                    render()
                }
            }.start()
            render()
        }
    }

    /** Tell that teacher, then forget this class on this phone. */
    private fun leave(cs: ClassStore) {
        val ctx = applicationContext; val code = cs.code; val label = cs.label()
        Thread {
            Sync.record(ctx, "left", "Left $label", listOf(code))
            Store(ctx).removeCode(code)
            runOnUiThread { render() }
        }.start()
    }

    private fun logout() {
        stopService(Intent(this, BlockerService::class.java)); RestartJob.cancel(applicationContext)
        store.logout(); tab = "home"; render()
    }

    /** Leaving a class needs that teacher's PIN. If no PIN is set, leaving is only allowed outside that class's hours. */
    private fun needPin(cs: ClassStore, action: () -> Unit) {
        if (cs.pinHash.isEmpty()) {
            if (cs.inClassHours()) toast("Class is on and no PIN is set. Ask your teacher.") else action()
            return
        }
        val et = Ui.codeInput(this, "PIN", true)
        Ui.dialog(this, "Enter the PIN", "Ask your teacher for the leave PIN of ${cs.label()}.", et, "OK") {
            if (Sync.sha256(cs.code + ":" + et.text.toString().trim()) == cs.pinHash) action() else toast("Wrong PIN")
        }
    }

    /** Tries the auto-start screen of common phone brands; falls back to the app info page. */
    private fun openAutoStart() {
        val tries = listOf(
            "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.transsion.phonemaster" to "com.cyin.himgr.autostart.AutoStartActivity"
        )
        for ((pkg, cls) in tries) {
            try { startActivity(Intent().setComponent(ComponentName(pkg, cls))); return } catch (e: Exception) { }
        }
        toast("Open Battery, then allow auto-launch / background activity")
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
