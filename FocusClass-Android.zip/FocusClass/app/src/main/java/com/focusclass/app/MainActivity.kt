package com.focusclass.app

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var store: Store
    private val handler = Handler(Looper.getMainLooper())
    private var statusView: TextView? = null
    private val ticker = object : Runnable {
        override fun run() { statusView?.text = statusText(); handler.postDelayed(this, 3000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        window.statusBarColor = Ui.DARK
        if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
    }

    override fun onResume() { super.onResume(); render(); handler.postDelayed(ticker, 3000) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    private fun render() { setContentView(if (store.loggedIn) dashboard() else loginView()) }

    private fun header(sub: String, big: Boolean): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = Ui.gradient(Ui.DARK, Ui.PRIMARY)
        setPadding(Ui.dp(context, 24), Ui.dp(context, if (big) 56 else 32), Ui.dp(context, 24), Ui.dp(context, if (big) 40 else 24))
        add(Ui.label(context, "FocusClass", if (big) 36f else 28f, Ui.WHITE, true))
        add(Ui.label(context, sub, 14f, Ui.SOFT), 4)
    }

    private fun page(head: View, body: LinearLayout): View = ScrollView(this).apply {
        setBackgroundColor(Ui.BG)
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(head, LinearLayout.LayoutParams(-1, -2))
            val p = Ui.dp(context, 16); body.setPadding(p, p, p, p)
            addView(body, LinearLayout.LayoutParams(-1, -2))
        })
    }

    /* ---------- Login / sign up ---------- */
    private fun loginView(): View {
        statusView = null
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val card = Ui.card(this)
        card.add(Ui.label(this, "Welcome", 22f, Ui.TEXT, true))
        card.add(Ui.label(this, "Log in or create a student account to continue.", 14f, Ui.MUTED), 4, 16)
        val email = Ui.input(this, "Email"); val pw = Ui.input(this, "Password (6+ characters)", true)
        card.add(email, 0, 10); card.add(pw)
        val msg = Ui.label(this, "", 14f, Ui.BAD); card.add(msg, 8, 8)
        lateinit var b1: Button; lateinit var b2: Button
        fun go(signUp: Boolean) {
            val e = email.text.toString().trim(); val p = pw.text.toString()
            if (e.isEmpty() || p.isEmpty()) { msg.text = "Enter your email and password."; return }
            msg.setTextColor(Ui.MUTED); msg.text = "Please wait..."; b1.isEnabled = false; b2.isEnabled = false
            Thread {
                val err = Sync.auth(applicationContext, signUp, e, p)
                runOnUiThread {
                    if (err == null) render() else { msg.setTextColor(Ui.BAD); msg.text = err; b1.isEnabled = true; b2.isEnabled = true }
                }
            }.start()
        }
        b1 = Ui.button(this, "Log in") { go(false) }; b2 = Ui.button(this, "Create account", false) { go(true) }
        card.add(b1, 0, 10); card.add(b2)
        body.add(card)
        return page(header("Stay focused. Learn better.", true), body)
    }

    /* ---------- Dashboard ---------- */
    private fun dashboard(): View {
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sc = Ui.card(this)
        sc.add(Ui.label(this, "CLASS STATUS", 12f, Ui.MUTED, true))
        statusView = Ui.label(this, statusText(), 16f); sc.add(statusView!!, 6)
        body.add(sc, 0, 12)

        val u = hasUsage(); val o = Settings.canDrawOverlays(this)
        step(1, "Allow usage access", "Lets FocusClass see which app is open so it can block the wrong ones.", u).apply {
            if (!u) add(Ui.button(context, "Open settings") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, 12)
            body.add(this, 0, 12) }
        step(2, "Allow display over other apps", "Needed to show the \"Blocked during class\" screen.", o).apply {
            if (!o) add(Ui.button(context, "Open settings") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }, 12)
            body.add(this, 0, 12) }
        val joined = store.code.isNotEmpty()
        step(3, "Join your class", if (joined) "You're in class ${store.code}. The teacher controls the schedule and allowed apps."
            else "Enter the class code from your teacher.", joined).apply {
            if (joined) add(Ui.button(context, "Leave class (PIN)", false, Ui.BAD) { askPin { leave() } }, 12)
            else add(Ui.button(context, "Join class") { join() }, 12)
            body.add(this, 0, 12) }

        body.add(Ui.button(this, "Log out", false, Ui.MUTED) { if (joined) askPin { logout() } else logout() }, 8)
        return page(header(store.email, false), body)
    }

    private fun step(n: Int, title: String, desc: String, done: Boolean): LinearLayout {
        val c = Ui.card(this)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(Ui.badge(this, if (done) "✓" else "$n", if (done) Ui.OK else Ui.PRIMARY))
        row.addView(Ui.label(this, title, 17f, Ui.TEXT, true),
            LinearLayout.LayoutParams(-2, -2).apply { leftMargin = Ui.dp(this@MainActivity, 12) })
        c.add(row); c.add(Ui.label(this, desc, 14f, Ui.MUTED), 8)
        return c
    }

    private fun statusText(): String {
        if (store.code.isEmpty()) return "Not in a class yet.\nFinish the steps below."
        return "Class ${store.code}\n${store.status}\n" +
            "Class mode: ${if (store.enabled) "ON" else "OFF"}  |  ${Store.fmt(store.startMin)} - ${Store.fmt(store.endMin)} (Mon-Fri)\n" +
            "Allowed apps: ${store.allowed.size}"
    }

    private fun hasUsage(): Boolean {
        val m = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return m.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun join() {
        if (!hasUsage() || !Settings.canDrawOverlays(this)) { toast("Finish steps 1 and 2 first"); return }
        val et = EditText(this).apply { hint = "Class code (6 letters)"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Join class").setView(et)
            .setPositiveButton("Join") { _, _ ->
                store.code = et.text.toString().trim().uppercase(); store.status = "Connecting..."
                startForegroundService(Intent(this, BlockerService::class.java))
                Thread { Sync.syncNow(applicationContext); runOnUiThread { render() } }.start()
                render() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun leave() { store.code = ""; store.status = "Not linked"; store.enabled = false; render() }

    private fun logout() { stopService(Intent(this, BlockerService::class.java)); store.logout(); render() }

    private fun askPin(ok: () -> Unit) {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("Enter PIN (default 1234)").setView(et)
            .setPositiveButton("OK") { _, _ -> if (et.text.toString() == store.pin) ok() else toast("Wrong PIN") }
            .setNegativeButton("Cancel", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
