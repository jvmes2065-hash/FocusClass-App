package com.focusclass.app

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var store: Store
    private val handler = Handler(Looper.getMainLooper())
    private var statusView: TextView? = null
    private var tab = "home"
    private val ticker = object : Runnable {
        override fun run() { statusView?.text = statusText(); updateRunner(); handler.postDelayed(this, 3000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        window.statusBarColor = Ui.DARK
        if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
    }

    override fun onResume() {
        super.onResume()
        if (store.loggedIn && store.code.isNotEmpty()) {
            // If the service has not run since the phone last started, the phone did not start us by itself.
            val boot = System.currentTimeMillis() - SystemClock.elapsedRealtime()
            if (store.lastAlive in 1L until boot) store.bootMissed = true
            try { startForegroundService(Intent(this, BlockerService::class.java)) } catch (e: Exception) { }
        }
        render(); handler.postDelayed(ticker, 3000)
    }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    private fun render() { setContentView(if (store.loggedIn) dashboard() else loginView()) }

    private var runner: RunnerView? = null
    private var runnerLabel: TextView? = null

    /** The blue top bar. With showRunner, a little mascot runs in the top-right corner while the app is working. */
    private fun header(sub: String, big: Boolean, showRunner: Boolean = false): View {
        val text = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 24), Ui.dp(context, if (big) 56 else 32), Ui.dp(context, 24), Ui.dp(context, if (big) 40 else 24))
            add(Ui.label(context, "FocusClass", if (big) 36f else 28f, Ui.WHITE, true))
            add(Ui.label(context, sub, 14f, Ui.SOFT), 4)
        }
        return FrameLayout(this).apply {
            background = Ui.gradient(Ui.DARK, Ui.PRIMARY)
            addView(text, FrameLayout.LayoutParams(-1, -2))
            if (showRunner) {
                val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
                val r = RunnerView(context); val l = Ui.label(context, "", 10f, Ui.SOFT).apply { gravity = Gravity.CENTER }
                runner = r; runnerLabel = l
                box.addView(r, LinearLayout.LayoutParams(Ui.dp(context, 48), Ui.dp(context, 48)))
                box.addView(l, LinearLayout.LayoutParams(-2, -2))
                addView(box, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
                    topMargin = Ui.dp(context, 12); rightMargin = Ui.dp(context, 16) })
                updateRunner()
            }
        }
    }

    /** Running = the protection service is alive (works offline too). Sleeping = it is not running. */
    private fun updateRunner() {
        val r = runner ?: return
        val joined = store.code.isNotEmpty()
        val working = joined && hasUsage() && Settings.canDrawOverlays(this) && System.currentTimeMillis() - store.lastTick < 15_000
        val offline = store.status.startsWith("No internet") || store.status.startsWith("Sign-in problem")
        r.working = working
        runnerLabel?.text = if (!joined) "Not in class" else if (!working) "Not running" else if (offline) "Working offline" else "Working"
    }

    private fun page(head: View, body: LinearLayout): View = ScrollView(this).apply {
        setBackgroundColor(Ui.BG)
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(head, LinearLayout.LayoutParams(-1, -2))
            val p = Ui.dp(context, 16); body.setPadding(p, p, p, p)
            addView(body, LinearLayout.LayoutParams(-1, -2))
        })
    }

    /* ---------- Login / sign up ---------- */
    private fun loginView(): View {
        statusView = null; runner = null; runnerLabel = null
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val card = Ui.card(this)
        card.add(Ui.label(this, "Welcome", 22f, Ui.TEXT, true))
        card.add(Ui.label(this, "Log in or create a student account to continue.", 14f, Ui.MUTED), 4, 16)
        val email = Ui.input(this, "Email"); val pw = Ui.input(this, "Password (6+ characters)", true)
        card.add(email, 0, 10); card.add(pw)
        val msg = Ui.label(this, "", 14f, Ui.BAD); card.add(msg, 8, 8)
        lateinit var b1: Button; lateinit var b2: Button
        fun go(signUp: Boolean) {
            val e = email.text.toString().trim(); val p = pw.text.toString()
            if (e.isEmpty() || p.isEmpty()) { msg.text = "Enter your email and password."; return }
            msg.setTextColor(Ui.MUTED); msg.text = "Please wait..."; b1.isEnabled = false; b2.isEnabled = false
            Thread {
                val err = Sync.auth(applicationContext, signUp, e, p)
                runOnUiThread {
                    if (err == null) render() else { msg.setTextColor(Ui.BAD); msg.text = err; b1.isEnabled = true; b2.isEnabled = true }
                }
            }.start()
        }
        b1 = Ui.button(this, "Log in") { go(false) }; b2 = Ui.button(this, "Create account", false) { go(true) }
        card.add(b1, 0, 10); card.add(b2)
        body.add(card)
        return page(header("Stay focused. Learn better.", true), body)
    }

    /* ---------- Main screen: Home / My profile ---------- */
    private fun dashboard(): View {
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.add(tabBar(), 0, 12)
        statusView = null
        if (tab == "profile") profile(body) else home(body)
        return page(header(store.email, false, true), body)
    }

    private fun tabBar(): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for ((id, name) in listOf("home" to "Home", "profile" to "My profile")) {
            addView(Ui.button(context, name, tab == id) { tab = id; render() },
                LinearLayout.LayoutParams(0, -2, 1f).apply { if (id == "home") rightMargin = Ui.dp(context, 8) })
        }
    }

    /** Home: status, plus only the setup steps that are NOT done yet. Finished steps disappear. */
    private fun home(body: LinearLayout) {
        val u = hasUsage(); val o = Settings.canDrawOverlays(this); val ad = adminOn(); val bt = batteryOk()
        val joined = store.code.isNotEmpty()
        val sc = Ui.card(this)
        sc.add(Ui.label(this, "CLASS STATUS", 12f, Ui.MUTED, true))
        statusView = Ui.label(this, statusText(), 16f); sc.add(statusView!!, 6)
        body.add(sc, 0, 12)

        if (joined && store.bootMissed) body.add(step(-1, "Start after restart is off",
            "FocusClass did not start by itself after your phone restarted, so it was not blocking until you opened it. Allow auto-start for FocusClass in the app settings (battery or auto-launch), then restart once to test.", false).apply {
            add(Ui.button(context, "Open app settings") {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }, 12) }, 0, 12)

        val left = listOf(u, o, ad, bt).count { !it }
        if (left > 0) body.add(Ui.label(this, "Finish setup ($left left)", 15f, Ui.TEXT, true), 4, 8)
        if (!u) body.add(step(1, "Allow usage access", "Lets FocusClass see which app is open so it can block the wrong ones.", false).apply {
            add(Ui.button(context, "Open settings") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, 12) }, 0, 12)
        if (!o) body.add(step(2, "Allow display over other apps", "Needed to show the \"Blocked during class\" screen.", false).apply {
            add(Ui.button(context, "Open settings") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }, 12) }, 0, 12)
        if (!ad) body.add(step(3, "Uninstall protection", "Stops FocusClass from being uninstalled during class. Your teacher is told if it is turned off.", false).apply {
            add(Ui.button(context, "Turn on") {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminCn)
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Stops FocusClass from being uninstalled during class. Your teacher is told if it is turned off.")) }, 12) }, 0, 12)
        if (!bt) body.add(step(4, "Keep running in background", "Stops the phone from putting FocusClass to sleep.", false).apply {
            add(Ui.button(context, "Allow") {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }, 12) }, 0, 12)

        if (!joined) {
            body.add(step(5, "Join your class", "Enter the class code from your teacher.", false).apply {
                add(Ui.button(context, "Join class") { join() }, 12) }, 0, 12)
        } else {
            val c = Ui.card(this)
            c.add(Ui.label(this, "YOUR CLASS", 12f, Ui.MUTED, true))
            c.add(Ui.label(this, store.code, 28f, Ui.PRIMARY, true), 4)
            c.add(Ui.label(this, scheduleText(), 14f, Ui.MUTED), 4)
            c.add(Ui.label(this, "Allowed during class", 14f, Ui.TEXT, true), 14, 4)
            c.add(Ui.label(this, allowedNames(), 14f, Ui.MUTED))
            c.add(Ui.button(this, "Leave class (PIN)", false, Ui.BAD) { needPin { leave() } }, 16)
            body.add(c, 0, 12)
        }
    }

    /** My profile: the student's own stats and activity log. */
    private fun profile(body: LinearLayout) {
        val c = Ui.card(this)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(Ui.badge(this, store.email.take(1).uppercase(), Ui.PRIMARY).apply { textSize = 22f; minWidth = Ui.dp(context, 56); minHeight = Ui.dp(context, 56) })
        val who = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        who.addView(Ui.label(this, store.email, 16f, Ui.TEXT, true))
        who.addView(Ui.label(this, if (store.code.isEmpty()) "Not in a class" else "Class ${store.code}", 13f, Ui.MUTED))
        row.addView(who, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = Ui.dp(this@MainActivity, 14) })
        c.add(row)
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(store.daysPresent to "Days present", store.blocked to "Blocked today", store.blockedTotal to "Blocked total", store.alertsTotal to "Alerts").forEachIndexed { i, (n, l) ->
            stats.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                val p = Ui.dp(context, 8); setPadding(p, p * 5 / 4, p, p * 5 / 4); background = Ui.shape(context, Ui.BG, 12)
                addView(Ui.label(context, "$n", 20f, Ui.TEXT, true).apply { gravity = Gravity.CENTER })
                addView(Ui.label(context, l, 11f, Ui.MUTED).apply { gravity = Gravity.CENTER })
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = Ui.dp(this@MainActivity, 6) })
        }
        c.add(stats, 16)
        body.add(c, 0, 12)

        val act = Ui.card(this)
        act.add(Ui.label(this, "Recent activity", 17f, Ui.TEXT, true), 0, 6)
        val items = store.activity()
        if (items.isEmpty()) act.add(Ui.label(this, "Nothing yet. Your activity shows here once you join a class.", 14f, Ui.MUTED))
        val fmt = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
        val names = mapOf("checkin" to "Checked in", "joined" to "Joined class", "left" to "Left class", "blocked" to "Blocked app", "tamper" to "Security alert")
        for (a in items.take(30)) {
            act.addView(View(this).apply { setBackgroundColor(Ui.LINE) }, LinearLayout.LayoutParams(-1, Ui.dp(this, 1)).apply { topMargin = Ui.dp(this@MainActivity, 8) })
            act.add(Ui.label(this, names[a.second] ?: a.second, 15f, if (a.second == "tamper") Ui.BAD else Ui.TEXT, true), 8)
            act.add(Ui.label(this, a.third, 13f, Ui.MUTED))
            act.add(Ui.label(this, fmt.format(Date(a.first)), 12f, Ui.MUTED))
        }
        body.add(act, 0, 12)
        body.add(Ui.button(this, "Log out", false, Ui.MUTED) { if (store.code.isNotEmpty()) needPin { logout() } else logout() }, 8)
    }

    private fun step(n: Int, title: String, desc: String, done: Boolean): LinearLayout {
        val c = Ui.card(this)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(Ui.badge(this, if (done) "\u2713" else if (n < 0) "!" else "$n", if (done) Ui.OK else if (n < 0) Ui.BAD else Ui.PRIMARY))
        row.addView(Ui.label(this, title, 17f, Ui.TEXT, true),
            LinearLayout.LayoutParams(-2, -2).apply { leftMargin = Ui.dp(this@MainActivity, 12) })
        c.add(row); c.add(Ui.label(this, desc, 14f, Ui.MUTED), 8)
        return c
    }

    private fun scheduleText(): String {
        val ps = store.periods()
        return if (ps.isEmpty()) "Schedule: ${Store.fmt(store.startMin)} - ${Store.fmt(store.endMin)} (Mon-Fri)"
        else "Subjects (Mon-Fri):\n" + ps.joinToString("\n") { "${it.name}  ${Store.fmt(it.start)} - ${Store.fmt(it.end)}" }
    }

    private fun allowedNames(): String {
        val names = store.allowed.mapNotNull {
            try { packageManager.getApplicationInfo(it, 0).loadLabel(packageManager).toString() } catch (e: Exception) { null }
        }.sorted()
        return "Phone, Messages and your home screen are always allowed." + if (names.isEmpty()) "" else "\n" + names.joinToString(", ")
    }

    private fun statusText(): String {
        val on = listOf(hasUsage(), Settings.canDrawOverlays(this), adminOn(), batteryOk()).count { it }
        val prot = if (on == 4) "Protection: all on" else "Protection: $on of 4 on"
        if (store.code.isEmpty()) return "Not in a class yet.\n$prot"
        val ps = store.periods(); val cur = store.currentPeriod()
        val whenText = if (ps.isEmpty()) "${Store.fmt(store.startMin)} - ${Store.fmt(store.endMin)} (Mon-Fri)"
            else if (cur != null) "Now: ${cur.name} (until ${Store.fmt(cur.end)})" else "No subject right now"
        val q = store.queueSize()
        return "Class ${store.code}\n${store.status}\nClass mode: ${if (store.enabled) "ON" else "OFF"}  |  $whenText\n" +
            (if (q > 0) "Waiting to send: $q update${if (q > 1) "s" else ""}\n" else "") + prot
    }

    private fun hasUsage(): Boolean {
        val m = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return m.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun adminOn() = (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(adminCn)
    private val adminCn get() = ComponentName(this, AdminReceiver::class.java)
    private fun batteryOk() = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    private fun join() {
        if (!hasUsage() || !Settings.canDrawOverlays(this) || !adminOn()) { toast("Finish steps 1 to 3 first"); return }
        val et = EditText(this).apply { hint = "Class code (6 letters)"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Join class").setView(et)
            .setPositiveButton("Join") { _, _ ->
                store.code = et.text.toString().trim().uppercase(); store.status = "Connecting..."
                startForegroundService(Intent(this, BlockerService::class.java))
                val ctx = applicationContext
                Thread {
                    Sync.syncNow(ctx); Sync.record(ctx, "joined", "Joined the class"); Sync.heartbeat(ctx)
                    runOnUiThread { render() }
                }.start()
                render() }
            .setNegativeButton("Cancel", null).show()
    }

    /** Tell the teacher, then clear the class on this phone. */
    private fun leave() {
        val ctx = applicationContext
        Thread {
            Sync.record(ctx, "left", "Left the class")
            runOnUiThread { store.code = ""; store.status = "Not linked"; store.enabled = false; store.pinHash = ""; render() }
        }.start()
    }

    private fun logout() {
        val ctx = applicationContext
        Thread {
            Sync.record(ctx, "left", "Logged out")
            runOnUiThread { stopService(Intent(this, BlockerService::class.java)); store.logout(); tab = "home"; render() }
        }.start()
    }

    /** Leaving needs the teacher's PIN. If no PIN is set, leaving is only allowed outside class hours. */
    private fun needPin(action: () -> Unit) {
        if (store.pinHash.isEmpty()) {
            if (store.inClassHours()) toast("Class is on and no PIN is set. Ask your teacher.") else action()
            return
        }
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("Enter the PIN from your teacher").setView(et)
            .setPositiveButton("OK") { _, _ ->
                if (Sync.sha256(store.code + ":" + et.text.toString().trim()) == store.pinHash) action() else toast("Wrong PIN") }
            .setNegativeButton("Cancel", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
