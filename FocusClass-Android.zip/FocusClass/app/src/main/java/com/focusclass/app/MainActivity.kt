package com.focusclass.app

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var status: TextView
    private val linked get() = store.code.isNotEmpty()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 64, 48, 48) }
        status = TextView(this).apply { textSize = 18f; setPadding(0, 0, 0, 32) }
        root.addView(status)
        fun btn(t: String, a: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { a() } })

        btn("1. Grant Usage Access") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        btn("2. Grant 'Display over other apps'") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("3. Join class with code") { join() }
        btn("Leave class (PIN)") { askPin { store.code = ""; store.status = "Not linked"; store.enabled = false; refresh() } }
        btn("Local mode: set start time") { local { pickTime(store.startMin) { store.startMin = it; refresh() } } }
        btn("Local mode: set end time") { local { pickTime(store.endMin) { store.endMin = it; refresh() } } }
        btn("Local mode: choose allowed apps") { local { chooseApps() } }
        btn("Local mode: turn ON / OFF") { local { toggle() } }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun local(a: () -> Unit) { if (linked) toast("Managed by your teacher") else a() }

    private fun refresh() {
        val perms = if (hasUsageAccess() && Settings.canDrawOverlays(this)) "Permissions: OK" else "Permissions: MISSING (steps 1 & 2)"
        status.text = (if (linked) "Class: ${store.code}\n${store.status}\n" else "Not in a class (local mode)\n") +
            "FocusClass: ${if (store.enabled) "ON" else "OFF"}\n" +
            "Schedule (Mon-Fri): ${Store.fmt(store.startMin)} - ${Store.fmt(store.endMin)}\n" +
            "Allowed apps: ${store.allowed.size}\n$perms"
    }

    private fun join() {
        if (!hasUsageAccess() || !Settings.canDrawOverlays(this)) { toast("Grant both permissions first"); return }
        val et = EditText(this).apply { hint = "Class code from teacher" }
        AlertDialog.Builder(this).setTitle("Join class").setView(et)
            .setPositiveButton("Join") { _, _ ->
                store.code = et.text.toString().trim().uppercase(); store.status = "Connecting..."
                startForegroundService(Intent(this, BlockerService::class.java))
                Thread { Sync.syncNow(applicationContext); runOnUiThread { refresh() } }.start()
                refresh() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun toggle() {
        if (store.enabled && store.inClassHours()) { askPin { store.enabled = false; refresh() }; return }
        if (store.enabled) store.enabled = false else {
            if (!hasUsageAccess() || !Settings.canDrawOverlays(this)) { toast("Grant both permissions first"); return }
            store.enabled = true
            startForegroundService(Intent(this, BlockerService::class.java))
        }
        refresh()
    }

    private fun hasUsageAccess(): Boolean {
        val m = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return m.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun pickTime(cur: Int, done: (Int) -> Unit) =
        TimePickerDialog(this, { _, h, m -> done(h * 60 + m) }, cur / 60, cur % 60, true).show()

    private fun chooseApps() {
        val apps = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .distinctBy { it.first }.filter { it.first != packageName }.sortedBy { it.second.lowercase() }
        val chosen = store.allowed.toMutableSet()
        AlertDialog.Builder(this).setTitle("Allowed during class")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), BooleanArray(apps.size) { apps[it].first in chosen }) { _, i, on ->
                if (on) chosen += apps[i].first else chosen -= apps[i].first }
            .setPositiveButton("Save") { _, _ -> store.allowed = chosen; refresh() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun askPin(ok: () -> Unit) {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("Enter PIN").setView(et)
            .setPositiveButton("OK") { _, _ -> if (et.text.toString() == store.pin) ok() else toast("Wrong PIN") }
            .setNegativeButton("Cancel", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
