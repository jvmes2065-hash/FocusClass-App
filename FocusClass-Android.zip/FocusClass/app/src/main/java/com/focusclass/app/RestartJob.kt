package com.focusclass.app

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent

/**
 * Quiet background check (no notification, no screen). Every ~15 min and after a restart it refreshes the teacher's
 * settings, and only starts FocusClass when a class is about to start or running. Outside class it does nothing visible.
 */
class RestartJob : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        val ctx = applicationContext
        Thread {
            val s = Store(ctx)
            if (s.code.isNotEmpty()) {
                Sync.syncNow(ctx); Sync.flush(ctx)
                if (s.inWatchWindow()) {
                    try { ctx.startForegroundService(Intent(ctx, BlockerService::class.java)) } catch (e: Exception) { }
                }
            }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean = false

    companion object {
        private const val ID = 77
        fun schedule(ctx: Context) {
            try {
                val js = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
                if (js.getPendingJob(ID) != null) return
                js.schedule(JobInfo.Builder(ID, ComponentName(ctx, RestartJob::class.java))
                    .setPeriodic(15 * 60 * 1000L).setPersisted(true).build())
            } catch (e: Exception) { }
        }
        fun cancel(ctx: Context) {
            try { (ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler).cancel(ID) } catch (e: Exception) { }
        }
    }
}
