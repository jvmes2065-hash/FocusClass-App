package com.focusclass.app

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Phone-wide data: login, trusted time, counters, the activity log, the offline queue and the list of joined classes. */
class Store(c: Context) {
    private val ctx = c.applicationContext
    private val p = ctx.getSharedPreferences("focusclass", Context.MODE_PRIVATE)
    private fun s(k: String, d: String = "") = p.getString(k, d)!!

    // ---- login ----
    var email: String get() = s("email"); set(v) = p.edit().putString("email", v).apply()
    var uid: String get() = s("uid"); set(v) = p.edit().putString("uid", v).apply()
    var idToken: String get() = s("idt"); set(v) = p.edit().putString("idt", v).apply()
    var refreshToken: String get() = s("rt"); set(v) = p.edit().putString("rt", v).apply()
    var tokenExp: Long get() = p.getLong("exp", 0L); set(v) = p.edit().putLong("exp", v).apply()
    val loggedIn: Boolean get() = refreshToken.isNotEmpty()
    fun logout() {
        for (code in codes()) ctx.deleteSharedPreferences("focusclass_c_$code")
        p.edit().clear().apply()
    }

    // ---- trusted time (server time + time since, so changing the phone's clock does not skip class) ----
    var bootAtSync: Int get() = p.getInt("bootAtSync", -1); set(v) = p.edit().putInt("bootAtSync", v).apply()
    fun currentBoot(): Int = Settings.Global.getInt(ctx.contentResolver, Settings.Global.BOOT_COUNT, 0)
    var srvBase: Long get() = p.getLong("srvBase", 0L); set(v) = p.edit().putLong("srvBase", v).apply()
    var elBase: Long get() = p.getLong("elBase", 0L); set(v) = p.edit().putLong("elBase", v).apply()
    var offset: Long get() = p.getLong("offset", 0L); set(v) = p.edit().putLong("offset", v).apply()
    var clockDay: String get() = s("clockDay"); set(v) = p.edit().putString("clockDay", v).apply()
    fun now(): Long {
        val e = SystemClock.elapsedRealtime()
        return if (srvBase > 0 && e >= elBase && currentBoot() == bootAtSync) srvBase + (e - elBase) else System.currentTimeMillis() + offset
    }

    // ---- service state and counters ----
    var bootMissed: Boolean get() = p.getBoolean("bootMissed", false); set(v) = p.edit().putBoolean("bootMissed", v).apply()
    var lastAlive: Long get() = p.getLong("alive", 0L); set(v) = p.edit().putLong("alive", v).apply()
    var lastTick: Long get() = p.getLong("tick", 0L); set(v) = p.edit().putLong("tick", v).apply()
    var blockedDay: String get() = s("bday"); set(v) = p.edit().putString("bday", v).apply()
    var blocked: Int get() = p.getInt("blocked", 0); set(v) = p.edit().putInt("blocked", v).apply()
    var daysPresent: Int get() = p.getInt("days", 0); set(v) = p.edit().putInt("days", v).apply()
    var blockedTotal: Int get() = p.getInt("btotal", 0); set(v) = p.edit().putInt("btotal", v).apply()
    var alertsTotal: Int get() = p.getInt("atotal", 0); set(v) = p.edit().putInt("atotal", v).apply()

    /** The student's own activity log (newest first, last 60 events). */
    fun addActivity(type: String, text: String) {
        synchronized(LOCK) {
            val old = org.json.JSONArray(s("activity", "[]"))
            val out = org.json.JSONArray().put(org.json.JSONObject().put("t", now()).put("type", type).put("text", text))
            for (i in 0 until minOf(old.length(), 59)) out.put(old.get(i))
            p.edit().putString("activity", out.toString()).apply()
            if (type == "checkin") daysPresent = daysPresent + 1
            if (type == "blocked") blockedTotal = blockedTotal + 1
            if (type == "tamper") alertsTotal = alertsTotal + 1
            Unit
        }
    }

    fun activity(): List<Triple<Long, String, String>> {
        val a = org.json.JSONArray(s("activity", "[]"))
        return (0 until a.length()).map { val o = a.getJSONObject(it); Triple(o.getLong("t"), o.getString("type"), o.getString("text")) }
    }

    // ---- updates that could not be sent yet (phone offline) ----
    fun hasQueue(): Boolean = s("queue", "[]").length > 2
    fun queueSize(): Int = org.json.JSONArray(s("queue", "[]")).length()
    fun enqueue(type: String, text: String, at: Long, code: String) {
        synchronized(LOCK) {
            val a = org.json.JSONArray(s("queue", "[]"))
            a.put(org.json.JSONObject().put("type", type).put("text", text).put("at", at).put("code", code))
            val out = org.json.JSONArray()
            for (i in maxOf(0, a.length() - 300) until a.length()) out.put(a.get(i))
            p.edit().putString("queue", out.toString()).apply()
            Unit
        }
    }
    fun queueItems(): List<org.json.JSONObject> = synchronized(LOCK) {
        val a = org.json.JSONArray(s("queue", "[]"))
        (0 until a.length()).map { a.getJSONObject(it) }
    }
    fun dropQueue(n: Int) {
        synchronized(LOCK) {
            val a = org.json.JSONArray(s("queue", "[]")); val out = org.json.JSONArray()
            for (i in n until a.length()) out.put(a.get(i))
            p.edit().putString("queue", out.toString()).apply()
            Unit
        }
    }

    // ---- joined classes (a student can join several) ----
    fun codes(): List<String> = s("codes").split(",").filter { it.isNotEmpty() }
    fun hasClass(): Boolean = codes().isNotEmpty()
    fun addCode(code: String) {
        synchronized(LOCK) {
            val l = codes().toMutableList(); if (code !in l) l.add(code)
            p.edit().putString("codes", l.joinToString(",")).apply()
            Unit
        }
    }
    fun removeCode(code: String) {
        synchronized(LOCK) {
            val l = codes().toMutableList(); l.remove(code)
            p.edit().putString("codes", l.joinToString(",")).apply()
            ctx.deleteSharedPreferences("focusclass_c_$code")
            Unit
        }
    }
    fun cls(code: String) = ClassStore(ctx, code)
    fun classes(): List<ClassStore> = codes().map { ClassStore(ctx, it) }

    /** Classes that are in session right now. */
    fun sessions(): List<ClassStore> = classes().filter { it.inClassHours() }
    fun inClassHours(): Boolean = classes().any { it.inClassHours() }
    fun inWatchWindow(): Boolean = classes().any { it.inWatchWindow() }
    /** An app is allowed only if every class in session allows it. */
    fun isAllowedNow(pkg: String): Boolean = sessions().all { pkg in it.allowedNow() }
    fun sessionEnd(): Int? = sessions().maxOfOrNull { it.endNow() }
    fun offline(): Boolean = classes().any { it.status.startsWith("No internet") || it.status.startsWith("Sign-in problem") }

    companion object {
        val LOCK = Any()
        val DEFAULT_ALLOWED = setOf("com.facebook.orca", "com.google.android.calculator",
            "com.android.calculator2", "com.sec.android.app.popupcalculator")
        fun fmt(min: Int) = "%02d:%02d".format(min / 60, min % 60)
    }
}

/** Everything the teacher controls for ONE class: schedule, days, subjects, allowed apps, PIN. */
class ClassStore(ctx: Context, val code: String) {
    private val g = Store(ctx)
    private val p = ctx.getSharedPreferences("focusclass_c_$code", Context.MODE_PRIVATE)
    private fun s(k: String, d: String = "") = p.getString(k, d)!!

    var name: String get() = s("name"); set(v) = p.edit().putString("name", v).apply()
    var status: String get() = s("status", "Connecting..."); set(v) = p.edit().putString("status", v).apply()
    var enabled: Boolean get() = p.getBoolean("enabled", false); set(v) = p.edit().putBoolean("enabled", v).apply()
    var startMin: Int get() = p.getInt("start", 8 * 60); set(v) = p.edit().putInt("start", v).apply()
    var endMin: Int get() = p.getInt("end", 15 * 60); set(v) = p.edit().putInt("end", v).apply()
    var pauseUntil: Long get() = p.getLong("pause", 0L); set(v) = p.edit().putLong("pause", v).apply()
    var pinHash: String get() = s("pinHash"); set(v) = p.edit().putString("pinHash", v).apply()
    /** A pause the teacher set for this student only (epoch ms, 0 = none). */
    var myPauseUntil: Long get() = p.getLong("myPause", 0L); set(v) = p.edit().putLong("myPause", v).apply()
    fun pausedUntil(): Long = maxOf(pauseUntil, myPauseUntil)
    fun isPaused(): Boolean = enabled && g.now() < pausedUntil()
    fun pausedClock(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(pausedUntil()))
    var periodsJson: String get() = s("periods", "[]"); set(v) = p.edit().putString("periods", v).apply()
    /** Class days as digits: 1=Sun ... 7=Sat. Default Mon-Fri. */
    var daysCsv: String get() = s("days", "23456"); set(v) = p.edit().putString("days", v).apply()
    var checkinDay: String get() = s("cday"); set(v) = p.edit().putString("cday", v).apply()
    var allowed: Set<String>
        get() = p.getStringSet("allowed", Store.DEFAULT_ALLOWED)!!
        set(v) = p.edit().putStringSet("allowed", v).apply()

    fun label(): String = name.ifEmpty { code }

    fun periods(): List<Period> {
        val a = org.json.JSONArray(periodsJson)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it); val ap = o.getJSONArray("apps")
            Period(o.getString("name"), o.getInt("start"), o.getInt("end"), (0 until ap.length()).map { k -> ap.getString(k) }.toSet())
        }
    }

    private fun minutesNow(): Int { val c = Calendar.getInstance().apply { timeInMillis = g.now() }; return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE) }
    private fun offDay(): Boolean {
        val d = Calendar.getInstance().apply { timeInMillis = g.now() }.get(Calendar.DAY_OF_WEEK)
        return !daysCsv.contains(d.toString()) // true on a day without class
    }

    /** The subject (period) happening right now, if the teacher set subjects. */
    fun currentPeriod(): Period? { if (offDay()) return null; val m = minutesNow(); return periods().firstOrNull { m in it.start until it.end } }
    fun allowedNow(): Set<String> = allowed + (currentPeriod()?.apps ?: emptySet())
    fun endNow(): Int = currentPeriod()?.end ?: endMin

    /** True from 30 min before class until 30 min after: the app syncs often in this window. */
    fun inWatchWindow(): Boolean {
        if (offDay()) return false
        val ps = periods()
        val lo = if (ps.isEmpty()) startMin else ps.minOf { it.start }
        val hi = if (ps.isEmpty()) endMin else ps.maxOf { it.end }
        return minutesNow() in (lo - 30)..(hi + 30)
    }

    fun inClassHours(): Boolean {
        if (!enabled || g.now() < pausedUntil() || offDay()) return false
        return if (periods().isEmpty()) minutesNow() in startMin until endMin else currentPeriod() != null
    }

    fun daysLabel(): String {
        val names = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        return daysCsv.filter { it in '1'..'7' }.map { names[it - '1'] }.joinToString(", ")
    }

    fun whenText(): String {
        if (isPaused()) return "Paused until ${pausedClock()}"
        val ps = periods(); val cur = currentPeriod()
        return if (ps.isEmpty()) "${Store.fmt(startMin)} - ${Store.fmt(endMin)} (${daysLabel()})"
        else if (cur != null) "Now: ${cur.name} (until ${Store.fmt(cur.end)})" else "No subject right now"
    }

    fun scheduleText(): String {
        val ps = periods()
        return if (ps.isEmpty()) "Schedule: ${Store.fmt(startMin)} - ${Store.fmt(endMin)} (${daysLabel()})"
        else "Subjects (${daysLabel()}):\n" + ps.joinToString("\n") { "${it.name}  ${Store.fmt(it.start)} - ${Store.fmt(it.end)}" }
    }
}

data class Period(val name: String, val start: Int, val end: Int, val apps: Set<String>)
