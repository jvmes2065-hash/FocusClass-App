package com.focusclass.app

import android.content.Context
import android.os.SystemClock
import java.util.Calendar

/** Local copy of the class settings. When a class code is set, Sync overwrites them from the teacher's settings. */
class Store(c: Context) {
    private val p = c.getSharedPreferences("focusclass", Context.MODE_PRIVATE)
    private fun s(k: String, d: String = "") = p.getString(k, d)!!

    var email: String get() = s("email"); set(v) = p.edit().putString("email", v).apply()
    val loggedIn: Boolean get() = refreshToken.isNotEmpty()
    fun logout() { p.edit().clear().apply() }

    var uid: String get() = s("uid"); set(v) = p.edit().putString("uid", v).apply()
    var pinHash: String get() = s("pinHash"); set(v) = p.edit().putString("pinHash", v).apply()
    var lastAlive: Long get() = p.getLong("alive", 0L); set(v) = p.edit().putLong("alive", v).apply()
    var checkinDay: String get() = s("cday"); set(v) = p.edit().putString("cday", v).apply()
    var blockedDay: String get() = s("bday"); set(v) = p.edit().putString("bday", v).apply()
    var blocked: Int get() = p.getInt("blocked", 0); set(v) = p.edit().putInt("blocked", v).apply()

    var srvBase: Long get() = p.getLong("srvBase", 0L); set(v) = p.edit().putLong("srvBase", v).apply()
    var elBase: Long get() = p.getLong("elBase", 0L); set(v) = p.edit().putLong("elBase", v).apply()
    var offset: Long get() = p.getLong("offset", 0L); set(v) = p.edit().putLong("offset", v).apply()
    var clockDay: String get() = s("clockDay"); set(v) = p.edit().putString("clockDay", v).apply()

    /** Trusted time: last server time + time since then, so changing the phone's clock does not skip class. */
    fun now(): Long {
        val e = SystemClock.elapsedRealtime()
        return if (srvBase > 0 && e >= elBase) srvBase + (e - elBase) else System.currentTimeMillis() + offset
    }

    var daysPresent: Int get() = p.getInt("days", 0); set(v) = p.edit().putInt("days", v).apply()
    var blockedTotal: Int get() = p.getInt("btotal", 0); set(v) = p.edit().putInt("btotal", v).apply()
    var alertsTotal: Int get() = p.getInt("atotal", 0); set(v) = p.edit().putInt("atotal", v).apply()

    /** The student's own activity log (newest first, last 60 events). */
    fun addActivity(type: String, text: String) {
        synchronized(LOCK) {
            val old = org.json.JSONArray(s("activity", "[]"))
            val out = org.json.JSONArray().put(org.json.JSONObject().put("t", now()).put("type", type).put("text", text))
            for (i in 0 until minOf(old.length(), 59)) out.put(old.get(i))
            p.edit().putString("activity", out.toString()).apply()
            if (type == "checkin") daysPresent = daysPresent + 1
            if (type == "blocked") blockedTotal = blockedTotal + 1
            if (type == "tamper") alertsTotal = alertsTotal + 1
            Unit
        }
    }

    fun activity(): List<Triple<Long, String, String>> {
        val a = org.json.JSONArray(s("activity", "[]"))
        return (0 until a.length()).map { val o = a.getJSONObject(it); Triple(o.getLong("t"), o.getString("type"), o.getString("text")) }
    }

    var code: String get() = s("code"); set(v) = p.edit().putString("code", v).apply()
    var status: String get() = s("status", "Not linked"); set(v) = p.edit().putString("status", v).apply()
    var idToken: String get() = s("idt"); set(v) = p.edit().putString("idt", v).apply()
    var refreshToken: String get() = s("rt"); set(v) = p.edit().putString("rt", v).apply()
    var tokenExp: Long get() = p.getLong("exp", 0L); set(v) = p.edit().putLong("exp", v).apply()
    var enabled: Boolean get() = p.getBoolean("enabled", false); set(v) = p.edit().putBoolean("enabled", v).apply()
    var startMin: Int get() = p.getInt("start", 8 * 60); set(v) = p.edit().putInt("start", v).apply()
    var endMin: Int get() = p.getInt("end", 15 * 60); set(v) = p.edit().putInt("end", v).apply()
    var pauseUntil: Long get() = p.getLong("pause", 0L); set(v) = p.edit().putLong("pause", v).apply()
    var pin: String get() = s("pin", "1234"); set(v) = p.edit().putString("pin", v).apply()
    var allowed: Set<String>
        get() = p.getStringSet("allowed", DEFAULT_ALLOWED)!!
        set(v) = p.edit().putStringSet("allowed", v).apply()

    /** True from 30 min before class until 30 min after (weekdays): the app syncs often in this window. */
    fun inWatchWindow(): Boolean {
        val c = Calendar.getInstance().apply { timeInMillis = now() }; val d = c.get(Calendar.DAY_OF_WEEK)
        if (d == Calendar.SATURDAY || d == Calendar.SUNDAY) return false
        return (c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)) in (startMin - 30)..(endMin + 30)
    }

    fun inClassHours(): Boolean {
        if (!enabled || now() < pauseUntil) return false
        val c = Calendar.getInstance().apply { timeInMillis = now() }
        val d = c.get(Calendar.DAY_OF_WEEK)
        if (d == Calendar.SATURDAY || d == Calendar.SUNDAY) return false
        val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return m in startMin until endMin
    }

    companion object {
        val LOCK = Any()
        val DEFAULT_ALLOWED = setOf("com.facebook.orca", "com.google.android.calculator",
            "com.android.calculator2", "com.sec.android.app.popupcalculator")
        fun fmt(min: Int) = "%02d:%02d".format(min / 60, min % 60)
    }
}
