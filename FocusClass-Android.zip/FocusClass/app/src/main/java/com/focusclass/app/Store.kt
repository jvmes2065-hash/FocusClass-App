package com.focusclass.app

import android.content.Context
import java.util.Calendar

/** Local copy of the class settings. When a class code is set, Sync overwrites them from the teacher's settings. */
class Store(c: Context) {
    private val p = c.getSharedPreferences("focusclass", Context.MODE_PRIVATE)
    private fun s(k: String, d: String = "") = p.getString(k, d)!!

    var code: String get() = s("code"); set(v) = p.edit().putString("code", v).apply()
    var status: String get() = s("status", "Not linked"); set(v) = p.edit().putString("status", v).apply()
    var idToken: String get() = s("idt"); set(v) = p.edit().putString("idt", v).apply()
    var refreshToken: String get() = s("rt"); set(v) = p.edit().putString("rt", v).apply()
    var tokenExp: Long get() = p.getLong("exp", 0L); set(v) = p.edit().putLong("exp", v).apply()
    var enabled: Boolean get() = p.getBoolean("enabled", false); set(v) = p.edit().putBoolean("enabled", v).apply()
    var startMin: Int get() = p.getInt("start", 8 * 60); set(v) = p.edit().putInt("start", v).apply()
    var endMin: Int get() = p.getInt("end", 15 * 60); set(v) = p.edit().putInt("end", v).apply()
    var pauseUntil: Long get() = p.getLong("pause", 0L); set(v) = p.edit().putLong("pause", v).apply()
    var pin: String get() = s("pin", "1234"); set(v) = p.edit().putString("pin", v).apply()
    var allowed: Set<String>
        get() = p.getStringSet("allowed", DEFAULT_ALLOWED)!!
        set(v) = p.edit().putStringSet("allowed", v).apply()

    fun inClassHours(): Boolean {
        if (!enabled || System.currentTimeMillis() < pauseUntil) return false
        val c = Calendar.getInstance()
        val d = c.get(Calendar.DAY_OF_WEEK)
        if (d == Calendar.SATURDAY || d == Calendar.SUNDAY) return false
        val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return m in startMin until endMin
    }

    companion object {
        val DEFAULT_ALLOWED = setOf("com.facebook.orca", "com.google.android.calculator",
            "com.android.calculator2", "com.sec.android.app.popupcalculator")
        fun fmt(min: Int) = "%02d:%02d".format(min / 60, min % 60)
    }
}
