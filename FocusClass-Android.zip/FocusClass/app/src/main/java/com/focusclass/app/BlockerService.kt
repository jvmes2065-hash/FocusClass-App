package com.focusclass.app

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.*
import android.provider.Telephony
import android.telecom.TelecomManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Foreground service: blocks non-allowed apps, syncs with the teacher, and reports presence and tampering. */
class BlockerService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: Store
    private var lastPkg: String? = null
    private var lastSync = 0L
    private var lastBeat = 0L
    private var lastBlockedPkg = ""
    private var lastBlockedAt = 0L
    private val tick = object : Runnable {
        override fun run() { check(); background(); handler.postDelayed(this, 1000) }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        store = Store(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cm", "FocusClass", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "cm").setContentTitle("FocusClass is running")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock).build())
        // If we were not running for a while during class, tell the teacher (force stop, phone off, restart).
        val now = System.currentTimeMillis(); val ctx = applicationContext
        if (store.code.isNotEmpty() && store.inClassHours() && store.lastAlive > 0 && now - store.lastAlive > 150_000) {
            val mins = (now - store.lastAlive) / 60_000
            Thread { Sync.record(ctx, "tamper", "FocusClass was not running for about $mins min during class (stopped, phone off or restarted)") }.start()
        }
        store.lastAlive = now
        handler.removeCallbacks(tick); handler.post(tick)
        return START_STICKY
    }

    private fun day() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun check() {
        updateForeground()
        val pkg = lastPkg ?: return
        if (!store.inClassHours()) return
        if (pkg in store.allowed || pkg in alwaysAllowed()) return
        val now = System.currentTimeMillis()
        if (pkg != lastBlockedPkg || now - lastBlockedAt > 60_000) {
            lastBlockedPkg = pkg; lastBlockedAt = now
            if (store.blockedDay != day()) { store.blockedDay = day(); store.blocked = 0 }
            store.blocked = store.blocked + 1
            val label = try { packageManager.getApplicationInfo(pkg, 0).loadLabel(packageManager).toString() } catch (e: Exception) { pkg }
            val ctx = applicationContext
            Thread { Sync.record(ctx, "blocked", "Tried to open $label") }.start()
        }
        startActivity(Intent(this, BlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Sync + heartbeat + daily check-in, less often outside class hours to save battery and data. */
    private fun background() {
        if (store.code.isEmpty()) return
        val now = System.currentTimeMillis(); val ctx = applicationContext; val watch = store.inWatchWindow()
        if (now - lastSync > (if (watch) 30_000 else 600_000)) {
            lastSync = now; store.lastAlive = now
            Thread { Sync.syncNow(ctx) }.start()
        }
        if (now - lastBeat > (if (watch) 60_000 else 900_000)) {
            lastBeat = now
            Thread { Sync.heartbeat(ctx) }.start()
        }
        if (store.inClassHours() && store.checkinDay != day()) {
            store.checkinDay = day()
            Thread { Sync.record(ctx, "checkin", "Present") }.start()
        }
    }

    private fun updateForeground() {
        val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = um.queryEvents(now - (if (lastPkg == null) 60_000 else 10_000), now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) lastPkg = e.packageName
        }
    }

    /** Apps that must always work: this app, phone, SMS, home screen, system UI. */
    private fun alwaysAllowed(): Set<String> {
        val s = mutableSetOf(packageName, "com.android.systemui", "com.android.incallui",
            "com.android.server.telecom", "com.google.android.dialer", "com.android.phone")
        (getSystemService(TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { s += it }
        Telephony.Sms.getDefaultSmsPackage(this)?.let { s += it }
        packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { s += it }
        return s
    }

    override fun onBind(i: Intent?): IBinder? = null
}
