package com.focusclass.app

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.*
import android.provider.Telephony
import android.telecom.TelecomManager

/** Foreground service: every second, checks the foreground app and shows the block screen if not allowed. */
class BlockerService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: Store
    private var lastPkg: String? = null
    private var lastSync = 0L
    private val tick = object : Runnable {
        override fun run() {
            check()
            if (System.currentTimeMillis() - lastSync > 20_000) {
                lastSync = System.currentTimeMillis()
                Thread { Sync.syncNow(applicationContext) }.start()
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        store = Store(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cm", "FocusClass", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "cm").setContentTitle("FocusClass is running")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock).build())
        handler.removeCallbacks(tick); handler.post(tick)
        return START_STICKY
    }

    private fun check() {
        updateForeground()
        val pkg = lastPkg ?: return
        if (!store.inClassHours()) return
        if (pkg in store.allowed || pkg in alwaysAllowed()) return
        startActivity(Intent(this, BlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun updateForeground() {
        val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = um.queryEvents(now - 10_000, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) lastPkg = e.packageName
        }
    }

    /** Apps that must always work: this app, phone, SMS, home screen, system UI. */
    private fun alwaysAllowed(): Set<String> {
        val s = mutableSetOf(packageName, "com.android.systemui", "com.android.incallui",
            "com.android.server.telecom", "com.google.android.dialer", "com.android.phone")
        (getSystemService(TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { s += it }
        Telephony.Sms.getDefaultSmsPackage(this)?.let { s += it }
        packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { s += it }
        return s
    }

    override fun onBind(i: Intent?): IBinder? = null
}
