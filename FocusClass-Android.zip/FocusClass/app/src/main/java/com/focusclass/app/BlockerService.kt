package com.focusclass.app

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.*
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Foreground service: blocks non-allowed apps, syncs with the teachers, and reports presence and tampering. */
class BlockerService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: Store
    private var lastPkg: String? = null
    private var lastSync = 0L
    private var lastBeat = 0L
    private var lastFlush = 0L
    private var lastTickWrite = 0L
    private var lastBlockedPkg = ""
    private var lastBlockedAt = 0L
    private val overlay by lazy { BlockOverlay(this) }
    private var blockTried = 0L
    private var streakPkg = ""
    private var streakStart = 0L
    private var streakCodes: List<String> = emptyList()
    private val tick = object : Runnable {
        override fun run() {
            val n = System.currentTimeMillis()
            if (n - lastTickWrite > 5_000) { lastTickWrite = n; store.lastTick = n } // "I am working" signal for the mascot
            // Outside class time (or after leaving every class) FocusClass stops itself: no notification, nothing running.
            if (!store.hasClass() || !store.inWatchWindow()) {
                handler.removeCallbacksAndMessages(null); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return
            }
            check(); background(); handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate() { super.onCreate(); CrashLog.install(this) }

    override fun onDestroy() { closeStreak(System.currentTimeMillis()); overlay.hide(); super.onDestroy() }

    private fun goHome() = startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    /** Counts how long the student stays in an app that is not allowed (shows in the teacher's records). */
    private fun trackStreak(pkg: String, codes: List<String>) {
        val now = System.currentTimeMillis()
        if (pkg == streakPkg) { if (pkg.isNotEmpty()) streakCodes = codes; return }
        closeStreak(now)
        streakPkg = pkg; streakStart = now; streakCodes = codes
    }

    private fun closeStreak(now: Long) {
        if (streakPkg.isEmpty()) return
        val secs = (now - streakStart) / 1000
        if (secs >= 20) {
            val label = try { packageManager.getApplicationInfo(streakPkg, 0).loadLabel(packageManager).toString() } catch (e: Exception) { streakPkg }
            val ctx = applicationContext; val codes = streakCodes
            val text = "Spent " + (if (secs >= 60) "${secs / 60} min" else "$secs sec") + " in $label"
            Thread { Sync.record(ctx, "usage", text, codes, secs) }.start()
        }
        streakPkg = ""
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        store = Store(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cm", "FocusClass", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "cm").setContentTitle("FocusClass is running")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock).build())
        // If we were not running for a while during class, tell the teachers (force stop, phone off, restart).
        val now = System.currentTimeMillis(); val ctx = applicationContext
        if (store.hasClass() && store.inClassHours() && store.lastAlive > 0 && now - store.lastAlive > 150_000) {
            val mins = (now - store.lastAlive) / 60_000
            Thread { Sync.record(ctx, "tamper", "FocusClass was not running for about $mins min during class (stopped, phone off or restarted)") }.start()
        }
        store.lastAlive = now
        RestartJob.schedule(applicationContext)
        handler.removeCallbacks(tick); handler.post(tick)
        return START_STICKY
    }

    private fun day() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun check() {
        updateForeground()
        val pkg = lastPkg ?: return
        val sessions = store.sessions()
        val bad = sessions.isNotEmpty() && !(sessions.all { pkg in it.allowedNow() } || pkg in alwaysAllowed())
        trackStreak(if (bad) pkg else "", sessions.map { it.code })
        if (!bad) { overlay.hide(); blockTried = 0L; return }
        val now = System.currentTimeMillis()
        if (pkg != lastBlockedPkg || now - lastBlockedAt > 60_000) {
            lastBlockedPkg = pkg; lastBlockedAt = now
            if (store.blockedDay != day()) { store.blockedDay = day(); store.blocked = 0 }
            store.blocked = store.blocked + 1
            val label = try { packageManager.getApplicationInfo(pkg, 0).loadLabel(packageManager).toString() } catch (e: Exception) { pkg }
            val ctx = applicationContext; val codes = sessions.map { it.code }
            Thread { Sync.record(ctx, "blocked", "Tried to open $label", codes) }.start()
        }
        if (sessions.all { it.monitorOnly }) return // control group: only record, do not block
        val t = System.currentTimeMillis()
        if (blockTried == 0L) blockTried = t
        if (!overlay.showing) startActivity(Intent(this, BlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        // Some phones (Xiaomi / MIUI) silently refuse to open the block screen from the background. If the blocked app
        // is still in front after 1.5 s, draw the block screen as an overlay window instead.
        if (t - blockTried > 1500 && !overlay.showing && Settings.canDrawOverlays(this)) {
            val e = store.sessionEnd(); val codes = sessions.map { it.code }; val ctx = applicationContext
            overlay.show("FocusClass is active" + (e?.let { " until " + Store.fmt(it) } ?: "") + ".\nStay focused!", { goHome() },
                { Thread { for (c in codes) Sync.requestPause(ctx, c, 5, "Requested from the block screen") }.start() })
        }
    }

    /** Sync + heartbeat + daily check-in, less often outside class hours to save battery and data. */
    private fun background() {
        val now = System.currentTimeMillis(); val ctx = applicationContext
        if (store.hasQueue() && now - lastFlush > 30_000) { lastFlush = now; Thread { Sync.flush(ctx) }.start() }
        if (!store.hasClass()) return
        val watch = store.inWatchWindow()
        if (now - lastSync > (if (watch) 30_000 else 600_000)) {
            lastSync = now; store.lastAlive = now
            Thread { Sync.syncNow(ctx) }.start()
        }
        if (now - lastBeat > (if (watch) 60_000 else 900_000)) {
            lastBeat = now
            Thread { Sync.heartbeat(ctx); Sync.uploadApps(ctx) }.start()
        }
        for (c in store.sessions()) {
            if (c.checkinDay != day()) {
                c.checkinDay = day()
                val code = c.code; val label = c.label()
                val late = c.nowMinutes() - c.sessionStartMin()
                val txt = if (late > c.lateAfter) "Late by $late min in $label" else "Present in $label"
                Thread { Sync.record(ctx, "checkin", txt, listOf(code)) }.start()
            }
        }
    }

    private fun updateForeground() {
        val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = um.queryEvents(now - (if (lastPkg == null) 60_000 else 10_000), now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) lastPkg = e.packageName
        }
    }

    /** Apps that must always work: this app, phone, SMS, home screen, system UI. */
    private fun alwaysAllowed(): Set<String> {
        val s = mutableSetOf(packageName, "com.android.systemui", "com.android.incallui",
            "com.android.server.telecom", "com.google.android.dialer", "com.android.phone")
        (getSystemService(TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { s += it }
        Telephony.Sms.getDefaultSmsPackage(this)?.let { s += it }
        packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { s += it }
        return s
    }

    override fun onBind(i: Intent?): IBinder? = null
}
