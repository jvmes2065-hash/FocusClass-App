package com.focusclass.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout

class BlockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val s = Store(this)
        window.statusBarColor = Ui.DARK
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = Ui.gradient(Ui.DARK, 0xFF0F172A.toInt())
            val p = Ui.dp(context, 32); setPadding(p, p, p, p)
        }
        root.add(Ui.label(this, "\uD83D\uDD12", 64f, Ui.WHITE).apply { gravity = Gravity.CENTER })
        root.add(Ui.label(this, "Blocked during class", 26f, Ui.WHITE, true).apply { gravity = Gravity.CENTER }, 12)
        root.add(Ui.label(this, "FocusClass is active until ${Store.fmt(s.endMin)}.\nStay focused!", 16f, Ui.SOFT)
            .apply { gravity = Gravity.CENTER }, 8, 32)
        root.add(Ui.button(this, "Go to home screen") { goHome() }, 0, 12)
        root.add(Ui.button(this, "Emergency call", false, Ui.BAD) {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))) })
        setContentView(root)
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = goHome()
}
