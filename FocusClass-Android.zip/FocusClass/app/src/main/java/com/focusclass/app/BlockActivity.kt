package com.focusclass.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val s = Store(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64); setBackgroundColor(Color.parseColor("#1E293B"))
        }
        root.addView(TextView(this).apply {
            text = "Blocked during class"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        root.addView(TextView(this).apply {
            text = "Restrictions end at ${Store.fmt(s.endMin)}"; textSize = 16f
            setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 24, 0, 48) })
        root.addView(Button(this).apply { text = "Go to home screen"; setOnClickListener { goHome() } })
        root.addView(Button(this).apply { text = "Emergency call"
            setOnClickListener { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))) } })
        setContentView(root)
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = goHome()
}
