package com.focusclass.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Toast
import android.widget.LinearLayout

class BlockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Ui.autoTheme(this); L.fil = Store(this).lang == "fil"
        val s = Store(this)
        window.statusBarColor = Ui.DARK
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = Ui.gradient(Ui.DARK, 0xFF0F172A.toInt())
            val p = Ui.dp(context, 32); setPadding(p, p, p, p)
        }
        root.add(Ui.label(this, "\uD83D\uDD12", 64f, Ui.WHITE).apply { gravity = Gravity.CENTER })
        root.add(Ui.label(this, "Blocked during class", 26f, Ui.WHITE, true).apply { gravity = Gravity.CENTER }, 12)
        root.add(Ui.label(this, "FocusClass is active${s.sessionEnd()?.let { " until " + Store.fmt(it) } ?: ""}.\nStay focused!", 16f, Ui.SOFT)
            .apply { gravity = Gravity.CENTER }, 8, 32)
        root.add(Ui.button(this, "Go to home screen") { goHome() }, 0, 12)
        root.add(Ui.button(this, "Ask my teacher for a pause", false) { askTeacher() }, 0, 12)
        root.add(Ui.button(this, "Emergency call", false, Ui.BAD) {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))) })
        setContentView(root)
    }

    /** Sends the teacher a request for a 5 minute pause. */
    private fun askTeacher() {
        val codes = Store(this).sessions().map { it.code }
        if (codes.isEmpty()) { Toast.makeText(this, "No class is on right now", Toast.LENGTH_SHORT).show(); return }
        val et = Ui.textInput(this, "Reason (for example: group work)")
        Ui.dialog(this, "Ask your teacher", "Your teacher gets a request to pause FocusClass for you for 5 minutes.", et, "Send") {
            val reason = et.text.toString().trim(); val ctx = applicationContext
            Thread {
                var ok = false
                for (c in codes) if (Sync.requestPause(ctx, c, 5, reason)) ok = true
                runOnUiThread { Toast.makeText(this, if (ok) "Request sent to your teacher" else "Could not send. Check your internet.", Toast.LENGTH_LONG).show() }
            }.start()
        }
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = goHome()
}
