package com.focusclass.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout

/** Loading screen shown for a moment when the app opens. */
class SplashActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Ui.DARK; window.navigationBarColor = Ui.DARK
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = Ui.gradient(Ui.DARK, Ui.PRIMARY)
        }
        val logo = LogoView(this).apply { alpha = 0f; scaleX = 0.8f; scaleY = 0.8f }
        val size = Ui.dp(this, 96)
        root.addView(logo, LinearLayout.LayoutParams(size, size))
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(600).start()

        root.add(Ui.label(this, "FocusClass", 32f, Ui.WHITE, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.05f }, 20)
        root.add(Ui.label(this, "Stay focused. Learn better.", 15f, Ui.SOFT).apply { gravity = Gravity.CENTER }, 4)

        val track = FrameLayout(this).apply { background = Ui.shape(context, 0x33FFFFFF, 3) }
        val fill = View(this).apply { background = Ui.shape(context, Ui.WHITE, 3); pivotX = 0f; scaleX = 0f }
        track.addView(fill, FrameLayout.LayoutParams(-1, -1))
        root.addView(track, LinearLayout.LayoutParams(Ui.dp(this, 160), Ui.dp(this, 4)).apply { topMargin = Ui.dp(this@SplashActivity, 32) })
        fill.animate().scaleX(1f).setDuration(1200).start()

        setContentView(root)
        handler.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 1400)
    }

    override fun onDestroy() { super.onDestroy(); handler.removeCallbacksAndMessages(null) }
}
