package com.focusclass.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** After a restart or update: only start FocusClass if a class is about to start or running. Otherwise stay quiet. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val s = Store(c)
        if (!s.hasClass()) return
        RestartJob.schedule(c.applicationContext)
        if (!s.inWatchWindow()) return
        s.bootMissed = false
        try { c.startForegroundService(Intent(c, BlockerService::class.java)) } catch (e: Exception) { }
    }
}
