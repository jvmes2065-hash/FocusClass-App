package com.focusclass.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Store(c).enabled || Store(c).code.isNotEmpty()) c.startForegroundService(Intent(c, BlockerService::class.java))
    }
}
