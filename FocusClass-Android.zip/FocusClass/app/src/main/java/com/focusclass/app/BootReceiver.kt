package com.focusclass.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Starts FocusClass again after the phone restarts or the app is updated. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val s = Store(c)
        if (!s.enabled && s.code.isEmpty()) return
        s.bootMissed = false
        try { c.startForegroundService(Intent(c, BlockerService::class.java)) } catch (e: Exception) { }
    }
}
