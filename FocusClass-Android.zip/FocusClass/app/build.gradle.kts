plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.focusclass.app"
    compileSdk = 34
    signingConfigs {
        // One fixed key, so new versions install over the old one (no uninstall needed after this update).
        getByName("debug") {
            storeFile = file("focusclass.keystore"); storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android"
        }
    }
    defaultConfig {
        applicationId = "com.focusclass.app"; minSdk = 26; targetSdk = 34
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt(); versionName = "0.2"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
